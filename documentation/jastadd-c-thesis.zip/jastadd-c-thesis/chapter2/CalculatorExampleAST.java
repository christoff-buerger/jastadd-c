new Calculator(new List() /* There are no values in memory */,
		new Addition(
				new Increment(
						new Constant(1)),
				new Division(
						new Variable("a"),
						new Substraction(
								new Constant(7),
								new Variable("b")))))