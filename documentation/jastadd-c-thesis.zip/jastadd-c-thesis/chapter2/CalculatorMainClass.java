package claculator;

import java.io.*;

import calculator.*;

/**
 * The final calculator compiler composing all generated
 * calculator parts together.
 */
public class CalculatorCompiler {
	/**
	 * Construct a calculator AST.
	 */
	public Calculator constructAST(java.io.Reader sourceCode) throws IOException, beaver.Scanner.Exception {
		CalculatorLexer lexer = new CalculatorLexer(sourceCode);
		CalculatorParser parser = new CalculatorParser();
		return (Calculator)parser.parse(lexer);
	}
	
	/**
	 * Perform the actual compilation, thus the computation
	 * of the expression's value.
	 */
	public void performAPICompilerActions(Calculator ast) {
		System.out.println(ast.Value());
	}
	
	/**
	 * Execute the calculator from the command line. The argument
	 * given is the source code file representing an expression to evaluate.
	 */
	public static void main(String[] args) throws IOException, beaver.Scanner.Exception {
		if (args.length < 1)
			throw new RuntimeException("No source code file specified.");
		File sourceCode = new File(args[0]);
		
		Calculator ast = constructAST(new FileReader(sourceCode));
		performAPICompilerActions(ast);
	}
}