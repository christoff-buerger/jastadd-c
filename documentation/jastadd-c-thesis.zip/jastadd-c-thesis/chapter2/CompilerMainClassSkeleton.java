package compiler;

import java.io.*;

import compiler.symbols.*;
import compiler.syntax.*;
import compiler.semantics.*;

/**
 * Glue code class composing all generated compiler parts together.
 */
public abstract class Compiler {
	/**
	 * Performs all the compilation actions needed to construct
	 * an evaluated AST.
	 */
	public ASTRootNode constructAST(java.io.Reader sourceCode) throws IOException, beaver.Scanner.Exception {
		GeneratedLexerClass lexer = new GeneratedLexerClass(sourceCode);
		GeneratedParserClass parser = new GeneratedParserClass();
		return (ASTRootNode)parser.parse(lexer);
	}
	
	/**
	 * Perform the actual compilation, thus access the AST's
	 * attributes to retrieve information and generate the
	 * compiler's output.
	 */
	public abstract void performAPICompilerActions(ASTRootNode ast);
	
	/**
	 * Executes the compiler from the command line. The argument
	 * given is the source code file to compile.
	 */
	public static void main(String[] args) throws IOException, beaver.Scanner.Exception {
		if (args.length < 1)
			throw new RuntimeException("No source code file specified.");
		File sourceCode = new File(args[0]);
		
		ASTRootNode ast = constructAST(new FileReader(sourceCode));
		performAPICompilerActions(ast);
	}
}