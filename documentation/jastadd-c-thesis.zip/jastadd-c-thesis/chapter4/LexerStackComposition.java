...
public class CLexicalAnalyser extends beaver.Scanner {
	...
	private beaver.Scanner lexerStack;
	
	// Composing JastAddC's lexers using the default character encoding:
	public void initialize (java.io.Reader inputTextStream) {
		lexerStack = new CStringLiteralConcatenator(
				new CCharacterMapper(
						new CLexer(
								new CSplicer(
										new CSourceReader(inputTextStream)))));
	}
	
	// Composing JastAddC's lexers using a user defined character encoding:
	public void initialize (java.io.InputStream inputTextStream,
			java.nio.Charset ENCODING) {
		lexerStack = new CStringLiteralConcatenator(
				new CCharacterMapper(
						new CLexer(
								new CSplicer(
										new CSourceReader(
												inputTextStream,
												ENCODING)))));
	}
	
	// Constructors:
	public CLexicalAnalyser(java.io.Reader inputTextStream) {
		initialize(inputTextStream);
	}
	
	public CLexicalAnalyser(java.io.InputStream inputTextStream,
			java.nio.Charset ENCODING) {
		initialize(inputTextStream, ENCODING);
	}
	...
}