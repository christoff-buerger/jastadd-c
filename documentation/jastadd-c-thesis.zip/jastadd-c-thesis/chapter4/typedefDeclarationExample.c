typedef int IntType, FuncType(IntType);

// The above is equivalent to:
typedef int IntType;
typedef int FuncType(IntType);