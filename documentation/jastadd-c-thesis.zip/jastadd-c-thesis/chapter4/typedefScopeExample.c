/* Global scope block level 0 */
typedef char* Type;
char c;

Type func(void)
{
	/* Function block level 1 */
	long l1 = sizeof(Type), Type = 3, l2 = sizeof(Type);
	if (l1 != sizeof(char*))
	{
		/* Compiler implementation error */
	}
	if (sizeof(Type) != sizeof(long))
	{
		/* Compiler implementation error */
	}
	if (l2 != sizeof(long))
	{
		/* Compiler implementation error */
	}
	{
		/* Function block level 1.4 */
		long l1 = Type;
		if (l1 != 3 || sizeof(Type) != sizeof(long))
		{
			/* Compiler implementation error */
		}
		typedef double Type;
		if (sizeof(Type) != sizeof(double))
		{
			/* Compiler implementation error */
		}
	}
	{
		/* Function block level 1.5 */
		typedef char Type;
		if (sizeof(Type) != sizeof(char))
		{
			/* Compiler implementation error */
		}
		{
			/* Function block level 1.5.2 */
			Type Type;
			Type = 'c';
			c = Type;
		}
	}
	char* pc = &c;
	return pc;
}