// The lexer must decide, that T is an identifier.
// Otherwise a syntax error results:
typedef long T;

void func1(void)
{
	// The lexer must decide, that T is a typedef-name.
	// Otherwise a syntax error results:
	T variable;
	...
}

void func2(void)
{
	// The lexer must decide, that T is an identifier.
	// Otherwise a syntax error results:
	int T;
	...
}

void func3(void)
{
	// The lexer must decide, that T is a typedef-name.
	// Otherwise a semantical error results
	// (IMPORTANT: On a syntactical view point T can be
	// both, an identifier or typedef-name):
	int size = sizeof(T);
}