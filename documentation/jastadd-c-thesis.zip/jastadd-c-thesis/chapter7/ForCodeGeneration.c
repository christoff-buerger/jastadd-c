{
	for (declaration; expression; expression)
		statement
	statement
}