SQL_RESULT* get_NUMBERs_by_WHERE(char* WHERE, char* dbs[99])
{
	SQL_RESULT res[99];
	int i=0;
	foreach (DB db:dbs;99)
	{
		res[i++] = SELECT NUMBER FROM db WHERE WHERE = WHERE;
	}
	return res;
}