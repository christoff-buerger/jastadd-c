int main(void)
{
	int a=1,b=2+3;
	return 4;
}