#!/bin/bash

clear
clear
clear

echo "=========================================>>> PDF Latex 1"
pdflatex -interaction=nonstopmode JastAddC_thesis.tex | grep !

echo "=========================================>>> Make Bibliography"
bibtex JastAddC_thesis

echo "=========================================>>> Make Index"
makeindex JastAddC_thesis.idx

echo "=========================================>>> PDF Latex 2"
pdflatex -interaction=nonstopmode JastAddC_thesis.tex | grep !

echo "=========================================>>> PDF Latex 3"
pdflatex -interaction=nonstopmode JastAddC_thesis.tex

echo "=========================================>>> Delete Intermediate Results"
# Filter directories, the bibliography, the TeX sources, the generated pdf and this shell script; Remove the rest. 
for f in `ls -p | grep -v / | grep -v bibliography.bib | grep -v .tex | grep -v .sty | grep -v .pdf | grep -v .bash`
do
	echo $f
	rm $f
done

open JastAddC_thesis.pdf
