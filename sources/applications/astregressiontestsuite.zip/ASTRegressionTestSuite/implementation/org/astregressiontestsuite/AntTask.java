package org.astregressiontestsuite;

import java.io.File;

import java.util.Collection;
import java.util.LinkedList;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.DirectoryScanner;
import org.testsuites.ConfigurationException;

/**
 * Ant task for the AST-Regression-Test-Suite. For details about the parameters
 * check the usage.text file.
 * 
 * @author C. Bürger
 *
 */
public class AntTask extends Task {
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected java.lang.Class<?> compilerClass;
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected Collection<File> sources;
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected File outdir;
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected Main.RegressionTestSuiteTask task;
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected File loggingFile;
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected boolean overwriteValidators;
	
	/**
	 * Constructor internally called by Ant.
	 */
	public AntTask() {
		sources = new LinkedList<File>();
		outdir = null;
		task = null;
		compilerClass = null;
		loggingFile = null;
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setCompiler(java.lang.Class<?> compilerClass) {
		this.compilerClass = compilerClass;
	}
	
	/**
	 * Called by Ant to set the specification files to compile based
	 * on the given Ant script.
	 * 
	 * @param sourceSpecifications Lists all the BitmaskType-Generator
	 * specifications to compile.
	 */
	public void addConfiguredFileSet(FileSet sourceSpecifications) {
		DirectoryScanner s = sourceSpecifications.getDirectoryScanner(getProject());
	    String[] files = s.getIncludedFiles();
	    String baseDir = s.getBasedir().getPath();
	    for(int i = 0; i < files.length; i++)
	    	this.sources.add(new File(baseDir + File.separator + files[i]));
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setOutdir(File validatorToCreate) {
		this.outdir = validatorToCreate;
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setMakevalid(boolean makeValid) {
		if (makeValid)
			task = Main.RegressionTestSuiteTask.MAKE_VALID;
		else task = Main.RegressionTestSuiteTask.VALIDATE;
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setLog(File loggingFile) {
		this.loggingFile = loggingFile;
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setOverwrite(boolean overwriteValidators) {
		this.overwriteValidators = overwriteValidators;
	}
	
	/**
	 * Method called by Ant to execute an Ant script.
	 */
	public void execute() throws BuildException {
		try {
			Main.execute(compilerClass,
					task,
					sources,
					outdir,
					loggingFile,
					overwriteValidators);
		} catch (ConfigurationException exc) {
			throw new BuildException(exc);
		}
	}
}
