package org.astregressiontestsuite;

import java.io.File;

import org.testsuites.ConfigurationException;
import org.testsuites.FailedTestException;

/**
 * Interface expected to be implemented by compilers usable to construct AST's for
 * the AST-Regression-Test-Suite.
 * 
 * @author C. Bürger
 *
 */
public interface ICompilerAdapter {
	/**
	 * Method of AST constructing compilers to generate an AST for a given source
	 * code file. The AST's can be used by the AST-Regression-Test-Suite to generate
	 * validators.
	 * 
	 * @param source The source code file to construct an AST for.
	 * @return The AST root node.
	 * @throws ConfigurationException Is thrown, if the compilation must be aborted, because the
	 * source code file can not be read or other technical issues have been encountered,
	 * thus the AST-Regression-Test-Suite can not be executed.
	 * @throws CompilationError Is thrown, if the source code contains failures.
	 */
	public IASTNode compile(File source) throws ConfigurationException, CompilationError;
	
	/**
	 * Interface the root node of AST's must implement in order to represent an AST
	 * usable by the AST-Regression-Test-Suite.
	 * 
	 * @author C. Bürger
	 *
	 */
	public interface IASTNode {
		/**
		 * Method to let an AST's root node generate an XML document representation
		 * of the AST.
		 * 
		 * @return The document representing this AST or null, if an error while it's
		 * creation has been encountered.
		 */
		public org.jdom.Document createXMLRepresentationOfTree();
		
		/**
		 * Method to construct the XML document parts representing this node
		 * and its complete subtree.
		 * 
		 * @return XML document parts for this node and it's subtree.
		 */
		public org.jdom.Element createXMLElementForTree();
	}
	
	/**
	 * Class used to represent compiler errors caused by faulty source code.
	 * 
	 * @author C. Bürger
	 *
	 */
	public class CompilationError extends FailedTestException {
		public static final long serialVersionUID = 1L;
		private File source;
		
		public CompilationError(File source, String message, Exception exc) {
			super(message, exc);
			this.source = source;
		}
		
		public CompilationError(File source, Exception exc) {
			super(exc);
			this.source = source;
		}
		
		public CompilationError(File source, String message) {
			super(message);
			this.source = source;
		}
		
		public String getMessage() {
			StringBuilder errorM = new StringBuilder();
			errorM.append("Erroneous source code [");
			if (source != null)
				errorM.append(source.getAbsolutePath());
			else errorM.append("§Anonymous Source§");
			errorM.append("]. Compiler reported {\n\t");
			errorM.append(super.getMessage());
			errorM.append("\n}");
			return errorM.toString();
		}
	}
}
