package org.astregressiontestsuite;

import java.io.IOException;
import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import java.text.SimpleDateFormat;

import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Handler;
import java.util.Date;
import java.util.TimeZone;

import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.CRC32;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Set;
import java.util.HashSet;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Attribute;
import org.jdom.output.XMLOutputter;
import org.testsuites.ConfigurationException;

/**
 * This class can be used to execute the AST-Regression-Test-Suite. It supports
 * the execution from command line. For details about command line usage check the
 * usage.txt file.
 * 
 * @author C. Bürger
 *
 */
public class Main {
	/**
	 * Represents a task to perform, thus if the AST's of sources have to be validated
	 * against their validators, or if the AST's are defined to be valid
	 * and their validators have to be generated.
	 * 
	 * @author C. Bürger
	 *
	 */
	public enum RegressionTestSuiteTask {VALIDATE, MAKE_VALID};
	
	/**
	 * Logger used to log performed AST-Regression-Test-Suite actions, as well
	 * as errors encountered.
	 */
	public final static Logger logger = initLogger();
	private static Logger initLogger() {
		try {
			Logger logger = Logger.getLogger(Main.class.getPackage().getName());

			// TODO: Is this a hack (surely it is).
			//       Any better solution for the "double console print error" with ant build scripts?
			Logger parent = logger.getParent();
			while (parent != null) {
				Handler[] handlers = parent.getHandlers();
				for (int i = 0; i < handlers.length; i++) {
					logger.log(Level.ALL,
							"Handler ["+ handlers[i].getClass().getName() +";"+
							handlers[i].getLevel().getLocalizedName() +
							"] for parent logger ["+ parent.getName() +
							"] removed (check "+ Main.class.getName() +" implementation)!");
					parent.removeHandler(handlers[i]);
				}
				parent = parent.getParent();
			}
			ConsoleHandler handler = new ConsoleHandler();
			handler.setEncoding("UTF-8");
			handler.setFormatter(new LoggingFormatter());
			handler.setLevel(Level.INFO);
			logger.addHandler(handler);
			
			return logger;
		} catch (Exception exc) {
			throw new RuntimeException(
					"Error while initializing the logger. Cause: "+ exc.getMessage(), exc);
		}
	}
	
	private static void printInputStreamOnStandardOut(InputStream input) throws IOException {
		StringBuilder stringbuf = new StringBuilder();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				input,
				"UTF-8"));
	
		char[] cbuf = new char[65536];

		int read = 0;
		while (true) {
			read = reader.read(cbuf, 0, 65536);
			if(read < 0)
				break;
			stringbuf.append(cbuf, 0, read);
		}
		
		System.out.append(stringbuf);
	}
	
	/**
	 * Executes the AST-Regression-Test-Suite with a task to perform.
	 * 
	 * @param task States, whether the sources should be validated or validators
	 * for the sources should be generated.
	 * @param sources If the task is to generate validators: the source files, for
	 * which validators, containing the source code and it's AST's, will generated.
	 * If the task is to run a regression test, thus to validate source code:
	 * the validators containing test cases (source code + expected AST).
	 * @param outdir The path and name of the validator to create (if any has to be
	 * created at all).
	 */
	public static void execute(java.lang.Class<?> compilerClass, RegressionTestSuiteTask task,
			Collection<File> sources, File outdir, File loggingFile, boolean overwriteValidators)
	throws ConfigurationException {
		// Check, if a compiler class is given and valid:
		if (compilerClass == null)
			throw new ConfigurationException(
					"No compiler for AST construction specified.");
		Object compiler = null;
		try {
			compiler = compilerClass.newInstance();
		} catch (InstantiationException exc) {
			throw new ConfigurationException(
					"The compiler class ["+
					compilerClass.getName() +
					"] specified can not be instanciated. Cause: "+
					exc.getMessage(), exc);
		} catch (IllegalAccessException exc) {
			throw new ConfigurationException(
					"The compiler class ["+
					compilerClass.getName() +
					"] specified can not be instanciated. Cause: "+
					exc.getMessage(), exc);
		}
		if (!(compiler instanceof ICompilerAdapter))
			throw new ConfigurationException(
					"The compiler class ["+
					compilerClass.getName() +
					"] specified is no ["+
					ICompilerAdapter.class.getName() +
					"] implementation.");
		
		// Check, if a task is given:
		if (task == null)
			throw new ConfigurationException(
					"No task to perfrom selected.");
		
		// Check, if all sources exist:
		if (sources == null || sources.size() < 1)
			throw new ConfigurationException(
					"No source(s) selected.");
		for (File source:sources) {
			if (source == null)
				throw new ConfigurationException(
						"The source §No Source Specified§ does not exist.");
			if (!source.exists())
				throw new ConfigurationException(
						"The source ["+ source.getAbsolutePath() +"] does not exist.");
			if (!source.isFile())
				throw new ConfigurationException(
						"The source ["+ source.getAbsolutePath() +"] is no file.");
		}
		
		// Initialize the logger:
		try {
			if (loggingFile != null) {
				if (loggingFile.getParentFile() == null || !loggingFile.getParentFile().exists())
					throw new ConfigurationException(
							"The specified logging file's directory ["+
							loggingFile.getAbsolutePath() +
							"] does not exist.");
				FileHandler fileHandler = new FileHandler(
						loggingFile.getAbsolutePath(),
						0,
						1,
						false);
				fileHandler.setEncoding("UTF-8");
				fileHandler.setFormatter(new LoggingFormatter());
				fileHandler.setLevel(Level.INFO);
				logger.addHandler(fileHandler);
			}
		} catch (IOException exc) {
			throw new ConfigurationException(
					"Error while initializing the logger. Cause: "+ exc.getMessage(), exc);
		}
		
		// General constraints are fulfilled
		// --> Start task specific execution (task specific constraints are checked there)
		if (task == RegressionTestSuiteTask.MAKE_VALID)
			makeValid((ICompilerAdapter)compiler, sources, outdir, overwriteValidators);
		else validate((ICompilerAdapter)compiler, sources);
	}
	
	private static void makeValid(ICompilerAdapter compiler,
			Collection<File> sources, File outdir, boolean overwriteValidators)
	throws ConfigurationException {
		// Check the validator directory:
		if (outdir == null)
			throw new ConfigurationException(
					"No validator to create specified.");
		if (outdir.exists()) {
			if (!overwriteValidators) {
				throw new ConfigurationException(
						"The validator ["+ outdir.getName() +"] can not be generated."+
						"\n\tA file named ["+ outdir.getName() +"] already exists."+
						"\n\tGeneration of validator for ["+
						outdir.getAbsolutePath() +
						"] aborted.");
			}
		}
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		dateFormat.setTimeZone(TimeZone.getDefault());
		logger.log(Level.INFO,
				"                                             AST-Regression-Test-Suite Report");
		logger.log(Level.INFO,
				"                                                 "+ dateFormat.format(date));
		logger.log(Level.INFO,
				"**************************************************************************************************************************");
		logger.log(Level.INFO, "");
		
		// As everything is alright, finally construct the validator:
		try {
			// In the following we like to generate the validator, which is a zip file:
			FileOutputStream fos = new FileOutputStream(outdir);
			ZipOutputStream zos = new ZipOutputStream(fos);
			CRC32 crc = new CRC32();
			int bytesRead;
			byte[] buffer = new byte[1024];
			
			Element testCase = new Element("ASTTestSuite");
			testCase.setAttribute(new Attribute("Created", dateFormat.format(date)));
			Document xmlDoc = new Document(testCase);
			
			logger.log(Level.INFO, "Start generation of validator\n\t["+ outdir.getAbsolutePath() +"].");
			if (outdir.exists())
				logger.log(Level.INFO,
						"Overwriting existing file\n\t["+ outdir.getAbsolutePath() +"].");
			
			Set<String> sourceNames = new HashSet<String>();
			for (File source:sources) {
				if (source.getName().equals("validator.xml")) {
					logger.log(Level.SEVERE,
							"No validator entry for the source ["+
							source.getAbsolutePath() +
							"] generated.\n\tA source named [validator.xml] is not permitted.");
					continue;
				}
				if (sourceNames.contains(source.getName())) {
					logger.log(Level.SEVERE,
							"The sources contain several times a source code file named ["+
							source.getName() +"].\n"+
							"\n\tNo validator entry for ["+
							source.getAbsolutePath() +
							"] generated!");
					continue;
				}
				sourceNames.add(source.getName());
				
				ICompilerAdapter.IASTNode ast = null;
				try {
					ast = compiler.compile(source);
				} catch (ConfigurationException exc) {
					logger.log(Level.SEVERE,
							"Source ["+ source.getAbsolutePath() +
							"] can not be compiled. Cause:\n\t"+
							exc.getMessage(), exc);
					continue;
				} catch (ICompilerAdapter.CompilationError exc) {
					logger.log(Level.SEVERE,
							exc.getMessage(),
							exc);
					continue;
				}
				
				Element astRootNode = ast.createXMLElementForTree();
				Element astElem = new Element("AST");
				astElem.setAttribute(new Attribute("SourceCodeFile", source.getName()));
				astElem.setAttribute(new Attribute("OriginalLocation", source.getParentFile().getAbsolutePath()));
				astElem.setAttribute(new Attribute("Testtype", "positive"));
				astElem.addContent(astRootNode);
				testCase.addContent(astElem);
				
				// Construct the source codes zip entry crc check sum:
				crc.reset();
				BufferedInputStream sourceIS = new BufferedInputStream(
						new FileInputStream(source));
				while ((bytesRead = sourceIS.read(buffer)) != -1) {
					crc.update(buffer, 0, bytesRead);
				}
				sourceIS.close();
				
				// Generate the source code's zip entry:
				sourceIS = new BufferedInputStream(
						new FileInputStream(source));
				ZipEntry entry = new ZipEntry(source.getName() + ".source");
				entry.setMethod(ZipEntry.STORED);
				entry.setCompressedSize(source.length());
				entry.setSize(source.length());
				entry.setCrc(crc.getValue());
				zos.putNextEntry(entry);
				while ((bytesRead = sourceIS.read(buffer)) != -1) {
					zos.write(buffer, 0, bytesRead);
				}
				sourceIS.close();
				
				logger.log(Level.INFO,
						"Successful generated validator entry for source"+
						"\n\t["+ source.getAbsolutePath() +"].");
			}
			
			// Construct the xml AST representation in memory:
			XMLOutputter xmlOutputter = new XMLOutputter();
			ByteArrayOutputStream xmlDocOS = new ByteArrayOutputStream(500000);
			xmlOutputter.output(xmlDoc, xmlDocOS);
			byte[] xmlDocBuffer = xmlDocOS.toByteArray();
			xmlDocOS.close();
			
			// Construct the AST xml file's zip entry crc check sum:
			crc.reset();
			ByteArrayInputStream xmlDocIS =
				new ByteArrayInputStream(xmlDocBuffer);
			while ((bytesRead = xmlDocIS.read(buffer)) != -1) {
				crc.update(buffer, 0, bytesRead);
			}
			xmlDocIS.close();
			
			// Generate the AST xml file's zip entry:
			xmlDocIS = new ByteArrayInputStream(xmlDocBuffer);
			ZipEntry entry = new ZipEntry("validator.xml");
			entry.setMethod(ZipEntry.STORED);
			entry.setCompressedSize(xmlDocBuffer.length);
			entry.setSize(xmlDocBuffer.length);
			entry.setCrc(crc.getValue());
			zos.putNextEntry(entry);
			while ((bytesRead = xmlDocIS.read(buffer)) != -1) {
				zos.write(buffer, 0, bytesRead);
			}
			xmlDocIS.close();
			
			zos.close();
			
			logger.log(Level.INFO, "Validator successful generated.");
			logger.log(Level.INFO, "");
		} catch (IOException exc) {
			logger.log(Level.SEVERE,
					"Can't generate validator ["+ outdir.getAbsolutePath() +"]."+
					"\n\tIOException: "+ exc.getMessage(),
					exc);
		}
	}
	
	private static void validate(ICompilerAdapter compiler,
			Collection<File> sources) {
		// TODO
	}
	
	/**
	 * The main method can be used to execute the test suite from command line.
	 * For details about command line usage check the usage.txt file or call
	 * this method without arguments to print the usage.txt files content on the
	 * standard output.
	 */
	public static void main(String[] args) throws ConfigurationException {
		// If no arguments are given print a help message.
		if (args.length < 1) {
			final String corruptedError = "FATAL: Can't open help file usage.txt.";
			
			InputStream usageInput =
				Main.class.getResourceAsStream("usage.txt");
			
			if (usageInput == null)
				throw new RuntimeException(corruptedError);
			
			try {
				printInputStreamOnStandardOut(usageInput);
			} catch (IOException exc) {
				throw new ConfigurationException(corruptedError, exc);
			}
			return;
		}
		
		// Read the input arguments and configure the JastAdd AST-Regression-Test-Suite appropriate.
		RegressionTestSuiteTask task = RegressionTestSuiteTask.VALIDATE;
		boolean overwriteValidators = true;
		String compilerClassName = null;
		File compilerClassLocation = null;
		Class<?> compilerClass = null;
		Collection<File> sources = null;
		File outdir = null;
		File loggingFile = null;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("-license")) {
				InputStream licenseInput =
					Main.class.getResourceAsStream("License.txt");
				
				final String corruptedError =
					"FATAL: Can't open license file License.txt.\nCorrupted BitmaskType-Generator version!";
				
				if (licenseInput == null)
					throw new ConfigurationException(corruptedError);
				
				try {	
					printInputStreamOnStandardOut(licenseInput);
				} catch (IOException exception) {
					throw new ConfigurationException(corruptedError);
				}
				continue;
			} else if (args[i].equals("-c")) {
				if (compilerClassName != null)
					throw new ConfigurationException(
							"Compiler to use several times specified.");
				i++;
				if (args.length < i || args[i].equals("-license") || args[i].equals("-c") ||
						args[i].equals("-s") || args[i].equals("-mv") || args[i].equals("-log") || args[i].equals("-ow"))
					throw new ConfigurationException(
							"No class file location for compiler parameter specified");
				compilerClassLocation = new File(args[i]);
				i++;
				if (args.length < i || args[i].equals("-license") || args[i].equals("-c") ||
						args[i].equals("-s") || args[i].equals("-mv") || args[i].equals("-log") || args[i].equals("-ow"))
					throw new ConfigurationException(
							"No class name for compiler parameter specified");
				compilerClassName = args[i];
				continue;
			} else if (args[i].equals("-s")) {
				if (sources != null)
					throw new ConfigurationException(
							"Source(s) several times specified.");
				sources = new LinkedList<File>();
				i++;
				int numberOfSources = 0;
				while (i < args.length) {
					if (args[i].equals("-license") || args[i].equals("-c") ||
							args[i].equals("-s") || args[i].equals("-mv") || args[i].equals("-log") || args[i].equals("-ow")) {
						i--;
						break;
					}
					sources.add(new File(args[i]));
					numberOfSources++;
					i++;
				}
				if (numberOfSources == 0)
					throw new ConfigurationException(
							"No source files for source parameter specified.");
				continue;
			} else if (args[i].equals("-mv")) {
				if (outdir != null)
					throw new ConfigurationException(
							"To make valide (-mv) several times specified.");
				task = RegressionTestSuiteTask.MAKE_VALID;
				i++;
				if (args.length < i || args[i].equals("-c") || args[i].equals("-license") ||
						args[i].equals("-s") || args[i].equals("-mv") || args[i].equals("-log") || args[i].equals("-ow"))
					throw new ConfigurationException(
							"No path and file name for the validator to generate specified.");
				outdir = new File(args[i]);
				i++;
				if (args.length < i) {
					if (args[i].equals("-ow"))
						overwriteValidators = true;
					else i--;
				}
				continue;
			} else if (args[i].equals("-log")) {
				if (loggingFile != null)
					throw new ConfigurationException(
							"File to write the log to is several times specified.");
				i++;
				if (args.length < i || args[i].equals("-c") || args[i].equals("-license") ||
						args[i].equals("-s") || args[i].equals("-mv") || args[i].equals("-log") || args[i].equals("-ow"))
					throw new ConfigurationException(
							"No file for logging parameter (-log) specified.");
				loggingFile = new File(args[i]);
				continue;
			} else throw new ConfigurationException(
					"Unknown command line parameter ["+ args[i] +"].");
		}
		
		// Load the specified compiler:
		if (compilerClassLocation != null) {
			URL[] compilerClassLocationURL = new URL[1];
			try {
				compilerClassLocationURL[0] = compilerClassLocation.toURI().toURL();
			} catch (MalformedURLException exception) {
				throw new ConfigurationException(exception);
			}
			
			URLClassLoader classLoader = new URLClassLoader(compilerClassLocationURL);
			try {
				compilerClass = classLoader.loadClass(compilerClassName);
			} catch (ClassNotFoundException exc) {
				throw new ConfigurationException(
						"The compiler specified can not be found. Cause: "+ exc.getMessage(), exc);
			}
		}
		
		execute(compilerClass, task, sources, outdir, loggingFile, overwriteValidators);
	}
}
