package org.testsuites;

import java.io.File;

import java.util.List;
import java.util.LinkedList;


/**
 * Class representing test files consisting of positive and
 * negative tests. This class allows to read and store
 * the tests of test files, as well as to execute them. A test
 * suite consists of a set of {@link IPositiveTest positive} tests and
 * a set of {@link INegativeTest negative} tests<br>
 * <br>
 * If tests are executed and no {@link ErrorsTestSuite}
 * exception is thrown, all tests of the test suite have been successful.
 * Otherwise some test(s) failed.
 * 
 * @author C. Bürger
 * 
 */
public abstract class ATestSuite {
	/**
	 * The test file represented by this test suite.
	 */
	public File testFile;
	/**
	 * List of all the positive tests contained in the test file
	 * this test suite object has been constructed from.
	 */
	public List<IPositiveTest> positiveTests;
	/**
	 * List of all the negative tests contained in the test file
	 * this test suite object has been constructed from.
	 */
	public List<INegativeTest> negativeTests;
	/**
	 * The description given for the test suite in the test file
	 * this test suite object has been constructed from.
	 */
	public String description;
	
	/**
	 * Constructs an object representing one test file, thus one
	 * test suite. To do so, an arbitrary test file is read, it's
	 * tests are stored in memory and methods to execute the tests are provided.
	 * 
	 * @param testFile The test file describing a set of tests. It
	 * will be read and form the tests for this test suite.
	 * @throws ConfigurationException Is thrown, if the test
	 * suite contains errors (implementation errors as well as errors in the
	 * test file read).
	 */
	public ATestSuite(File testFile) throws ConfigurationException {
		initialize(testFile);
	}
	
	/**
	 * Semantics are the same like the ones of the {@link #ATestSuite(File)}
	 * constructor, expect no new test suite is constructed, instead this test suite's
	 * tests will be the ones specified in the test file argument. Already stored
	 * tests in this test suite will be deleted.
	 */
	public abstract void initialize(File testFile) throws ConfigurationException;
	
	/**
	 * Executes all {@link #runPositiveTests() positive} and {@link #runNegativeTests()
	 * negative} tests of this test suite. If a test fails, an {@link ErrorsTestSuite}
	 * exception is thrown <b>after</b> all tests have been executed.
	 * 
	 * @throws ConfigurationException Is thrown if the test suite contains
	 * errors.
	 * @throws ErrorsLexicalTestSuite Is thrown if a test failed.
	 */
	public void runTests() throws ConfigurationException, ErrorsTestSuite {
		ErrorsTestSuite errors = null;
		
		try {
			runPositiveTests();
		} catch (ErrorsTestSuite error) {
			errors = error;
		}
		
		try {
			runNegativeTests();
		} catch (ErrorsTestSuite error) {
			if (errors != null)
				errors.errorsNegativeTests = error.errorsNegativeTests;
			else errors = error; 
		}
		
		if (errors != null)
			throw errors;
	}
	
	/**
	 * Executes all {@link IPositiveTest}s of this test suite. If a test
	 * fails, an {@link ErrorsTestSuite} exception is thrown <b>after</b>
	 * all tests have been executed.
	 * 
	 * @throws ConfigurationException Is thrown if the test suite
	 * contains errors.
	 * @throws ErrorsTestSuite Is thrown if a test failed.
	 */
	public void runPositiveTests() throws ConfigurationException, ErrorsTestSuite {
		ErrorsTestSuite errorsSuite = new ErrorsTestSuite();
		errorsSuite.testFile = testFile;
		errorsSuite.description = description;
		ErrorsPositiveTests errors = new ErrorsPositiveTests();
		errorsSuite.errorsPositiveTests = errors;
		
		int testNumber = 1;
		for (IPositiveTest positiveTest:positiveTests) {
			try {
				positiveTest.runTest();
			} catch (IPositiveTest.ErrorPositiveTest error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errorsSuite;
	}
	
	/**
	 * Executes all {@link INegativeTest}s of this test suite. If a test
	 * fails, an {@link ErrorsTestSuite} exception is thrown <b>after</b>
	 * all tests have been executed.
	 * 
	 * @throws ConfigurationException Is thrown if the test suite
	 * contains errors.
	 * @throws ErrorsTestSuite Is thrown if a test failed.
	 */
	public void runNegativeTests() throws ConfigurationException, ErrorsTestSuite {
		ErrorsTestSuite errorsSuite = new ErrorsTestSuite();
		errorsSuite.testFile = testFile;
		errorsSuite.description = description;
		ErrorsNegativeTests errors = new ErrorsNegativeTests();
		errorsSuite.errorsNegativeTests = errors;
		
		int testNumber = 1;
		for (INegativeTest negativeTest:negativeTests) {
			try {	
				negativeTest.runTest();
			} catch (INegativeTest.ErrorNegativeTest error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errorsSuite;
	}
	
	/**
	 * Exceptions thrown, if a test contained in a {@link ATestSuite}
	 * failed, while executing a test method of the {@link ATestSuite}
	 * class. As tests in a test suite are distinguished in {@link
	 * IPositiveTest positive} and {@link INegativeTest negative}
	 * tests, this class wrapps an {@link ErrorsPositiveTests}
	 * and an {@link ErrorsNegativeTests} exception.<br>
	 * <br>
	 * Instances of this class are always associated with :<br>
	 *  - a {@link ATestSuite} object of which<br>
	 *  - one of it's tests methods has been executed and<br>
	 *  - some of it's tests failed while execution and<br>
	 *  - the failed tests are represented by this {@link ErrorsTestSuite}
	 *    exception.<br>
	 * <br>
	 * {@link ErrorsTestSuite} exceptions are only thrown by test methods of
	 * {@link ATestSuite}s if some tests during their execution failed,
	 * and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsTestSuite extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private File testFile;
		private String description;
		private ErrorsPositiveTests errorsPositiveTests;
		private ErrorsNegativeTests errorsNegativeTests;
		
		private ErrorsTestSuite() {
			errorsPositiveTests = null;
			errorsNegativeTests = null;
		}
		
		public String getMessage() {
			final String lineSep = System.getProperty("line.separator");
			StringBuilder result = new StringBuilder(512);
			
			result.append("Failed tests in file [");
			result.append(testFile.getAbsolutePath());
			result.append("]: ");
			if (errorsPositiveTests != null) {
				result.append(lineSep);
				result.append("\t");
				result.append(errorsPositiveTests.getMessage());
			}
			if (errorsNegativeTests != null) {
				result.append(lineSep);
				result.append("\t");
				result.append(errorsNegativeTests.getMessage());
			}
			result.append(lineSep);
			result.append("\t");
			result.append("Test file description: ");
			result.append(description);
			
			return result.toString();
		}
		
		/**
		 * Returns the test file associated with the {@link ATestSuite}
		 * this {@link ErrorsTestSuite} exception has been thrown for, because one
		 * of the test suites tests failed while executing a test
		 * suites test method.
		 * 
		 * @return Test file associated with the test suite containing
		 * failed tests reported by this {@link ErrorsTestSuite} exception.
		 */
		public File getTestFile() {
			return testFile;
		}
		
		/**
		 * Returns the description of the test suite, as it has been given
		 * in the test file represented by the test suite.
		 * 
		 * @return Description of the test suite.
		 */
		public String getTestFileDescription() {
			return description;
		}
		
		/**
		 * Returns the {@link ErrorsPositiveTests} represented
		 * by this {@link ErrorsTestSuite} or null if this {@link ErrorsTestSuite}
		 * object doesn't represent failed positive tests. E.g. this might be the
		 * case, if only negative tests have been executed and some of it failed,
		 * which still results in an {@link ErrorsTestSuite} exception.
		 * 
		 * @return Positive failed tests exception or null, if no positive test
		 * failed while executing test methods of a {@link ATestSuite}s
		 * test method.
		 */
		public ErrorsPositiveTests hasErrorsPositiveTests() {
			return errorsPositiveTests;
		}
		
		/**
		 * Returns the {@link ErrorsNegativeTests} represented
		 * by this {@link ErrorsTestSuite} or null if this {@link ErrorsTestSuite}
		 * object doesn't represent failed negative tests. E.g. this might be the
		 * case, if only positive tests have been executed and some of it failed,
		 * which still results in an ErrorsLexicalTestSuite exception.
		 * 
		 * @return Negative failed tests exception or null, if no negative test
		 * failed while executing test methods of a {@link ATestSuite}s
		 * test method.
		 */
		public ErrorsNegativeTests hasErrorsNegativeTests() {
			return errorsNegativeTests;
		}
	}
	
	/**
	 * Exceptions thrown, if some {@link IPositiveTest positive} test(s)
	 * contained in a {@link ATestSuite} failed, while executing a test
	 * method of the {@link ATestSuite}.<br>
	 * <br>
	 * As a test suite may contain an arbitrary number of positive
	 * tests, it is necessary to know, which positive tests actually
	 * failed while executing a test method of the test suite. To do so,
	 * the {@link ErrorsPositiveTests} exception contains, additionally
	 * to a list of all the {@link IPositiveTest.ErrorPositiveTest positive
	 * test exceptions} of the positive tests failed, also their numbers in the list
	 * of positive tests of the test suite for which this
	 * {@link ErrorsPositiveTests} has been thrown.
	 * <br>
	 * {@link ErrorsPositiveTests} exceptions are only thrown by test
	 * methods of {@link ATestSuite}s if some <b>positive</b> test(s)
	 * during their execution failed, and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsPositiveTests extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private List<Integer> testNumbers;
		private List<IPositiveTest.ErrorPositiveTest> testErrors;
		
		private ErrorsPositiveTests() {
			testNumbers = new LinkedList<Integer>();
			testErrors = new LinkedList<IPositiveTest.ErrorPositiveTest>();
		}
		
		public String getMessage() {
			return "["+ testNumbers.size() + "] positive test(s) from " +
				ATestSuite.class.getName() + " instance failed.";
		}
		
		/**
		 * Returns the number of failed positive tests while executing a test
		 * method of a {@link ATestSuite}.
		 * 
		 * @return Number of failed positive tests, while executing a test method
		 * of the {@link ATestSuite} this {@link ErrorsPositiveTests}
		 * is associated with.
		 */
		public int getNumberOfFailedTests() {
			return testNumbers.size();
		}
		
		/**
		 * Returns the list position in the list of positive tests of the
		 * {@link ATestSuite} this {@link ATestSuite.ErrorsPositiveTests}
		 * exception is associated with.
		 *  
		 * @param nthFailedTest The position in the list of {@link IPositiveTest.ErrorPositiveTest
		 * positive tests} of this {@link ATestSuite.ErrorsPositiveTests} object.
		 * @return The position in the list of {@link IPositiveTest}s of
		 * the {@link ATestSuite} this {@link ATestSuite.ErrorsPositiveTests} object is
		 * associated with.
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Returns the n'th {@link IPositiveTest.ErrorPositiveTest positive test exception} in the
		 * list of positive test exceptions of this {@link ErrorsPositiveTests}.
		 * 
		 * @param nthFailedTest Position in the list of {@link IPositiveTest.ErrorPositiveTest} of
		 * this {@link ErrorsPositiveTests}.
		 * @return The {@link IPositiveTest.ErrorPositiveTest} exception at the given position.
		 */
		public IPositiveTest.ErrorPositiveTest getTestError(int nthFailedTest) {
			return testErrors.get(nthFailedTest);
		}
	}
	
	/**
	 * The semantics of this exception are analog to the ones of the
	 * {@link ATestSuite.ErrorsPositiveTests} class,
	 * expect, instead of positive failed lexical tests, negative ones are treated.<br>
	 * <br>
	 * So associated classes are :<br>
	 *  - {@link ATestSuite}<br>
	 *  - {@link INegativeTest}<br>
	 *  - {@link INegativeTest.ErrorNegativeTest}<br>
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsNegativeTests extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private List<Integer> testNumbers;
		private List<INegativeTest.ErrorNegativeTest> testErrors;
		
		private ErrorsNegativeTests() {
			testNumbers = new LinkedList<Integer>();
			testErrors = new LinkedList<INegativeTest.ErrorNegativeTest>();
		}
		
		public String getMessage() {
			return "["+ testNumbers.size() + "] negative test(s) from " +
				ATestSuite.class.getName() + " instance failed.";
		}
		
		/**
		 * Analog to
		 * {@link ATestSuite.ErrorsPositiveTests#getNumberOfFailedTests()}
		 * method.
		 * 
		 */
		public int getNumberOfFailedTests() {
			return testNumbers.size();
		}
		
		/**
		 * Analog to
		 * {@link ATestSuite.ErrorsPositiveTests#getTestNumber(int)}
		 * method.
		 * 
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Analog to
		 * {@link ATestSuite.ErrorsPositiveTests#getTestError(int)}
		 * method.
		 * 
		 */
		public INegativeTest.ErrorNegativeTest getTestError(int nthFailedTest) {
			return testErrors.get(nthFailedTest);
		}
	}
}
