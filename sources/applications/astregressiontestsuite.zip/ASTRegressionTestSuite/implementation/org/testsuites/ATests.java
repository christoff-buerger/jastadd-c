package org.testsuites;

import java.io.File;

import java.util.List;
import java.util.LinkedList;

public abstract class ATests {
	/**
	 * List of all the {@link ATestSuite}s contained in this {@link ATests}
	 * object.
	 */
	public List<ATestSuite> tests;
	
	/**
	 * Initializes, stores and returns an object representing a collection of
	 * test suites.
	 * 
	 * @param testFiles The files representing test cases to execute.
	 * @throws ConfigurationException Thrown, if the tests
	 * them self are erroneous.
	 */
	public ATests (List<File> testFiles) throws ConfigurationException {
		initialize(testFiles);
	}
	
	/**
	 * Initializes and stores this collection of test suites. The
	 * collection is emptied before, thus the semantics are the same as for
	 * the {@link #ATests(List) constructor}.
	 */
	public abstract void initialize (List<File> testFiles) throws ConfigurationException;
	
	/**
	 * Executes all tests of all the test suites contained in this
	 * {@link ATestSuite}s collection. The semantics are the same like
	 * executing all {@link #runPositiveTests() positive} and
	 * {@link #runNegativeTests() negative} tests of the test suites
	 * contained.
	 * 
	 * @throws ConfigurationException Thrown, if the
	 * tests them self are erroneous.
	 * @throws ErrorsTests Thrown, if any test of the
	 * {@link ATestSuite}s contained failed. All tests are still
	 * executed, thus the failed test exception is thrown after
	 * execution.
	 */
	public void runTests() throws ConfigurationException, ErrorsTests {
		ErrorsTests errors = new ErrorsTests();
		
		int testNumber = 1;
		for (ATestSuite testSuite:tests) {
			try {
				testSuite.runTests();
			} catch (ATestSuite.ErrorsTestSuite error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errors;
	}
	
	/**
	 * Executes all positive tests of all the test suites contained
	 * in this {@link ATestSuite} collection. Thus,
	 * the {@link ATestSuite#runPositiveTests()} method for each test
	 * suite is executed.
	 * 
	 * @throws ConfigurationException Thrown, if the tests
	 * them self are erroneous.
	 * @throws ErrorsTests Thrown, if any positive test of the
	 * {@link ATestSuite}s contained failed. All tests
	 * are still executed, thus the failed test exception is thrown after
	 * execution.
	 */
	public void runPositiveTests() throws ConfigurationException, ErrorsTests {
		ErrorsTests errors = new ErrorsTests();
		
		int testNumber = 1;
		for (ATestSuite testSuite:tests) {
			try {
				testSuite.runPositiveTests();
			} catch (ATestSuite.ErrorsTestSuite error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errors;
	}
	
	/**
	 * Semantics are the same as for the {@link #runPositiveTests()}
	 * method, expect only negative tests are executed.
	 */
	public void runNegativeTests() throws ConfigurationException, ErrorsTests {
		ErrorsTests errors = new ErrorsTests();
		
		int testNumber = 1;
		for (ATestSuite testSuite:tests) {
			try {
				testSuite.runNegativeTests();
			} catch (ATestSuite.ErrorsTestSuite error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errors;
	}
	
	/**
	 * The class implements exception thrown, if any test failed, while performing
	 * tests of a {@link ATests} instance. So instances of this class are
	 * thrown by the test methods of the {@link ATests} class.<br>
	 * <br>
	 * An {@link ErrorsTests} exception contains all {@link ATestSuite.ErrorsTestSuite}
	 * exceptions thrown by {@link ATestSuite}s, because any of their tests
	 * has been invoked and failed during performing tests of a {@link ATests}
	 * instance. Additionally it associates a number with every failed
	 * {@link ATestSuite}, telling which test suite it is in the
	 * {@link ATests} instance's test suite collection.
	 * <br>
	 * {@link ErrorsTests} exceptions are only thrown by test methods of
	 * {@link ATests} objects if some tests during their execution failed,
	 * and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsTests extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private List<Integer> testNumbers;
		private List<ATestSuite.ErrorsTestSuite> testErrors;
		
		private ErrorsTests() {
			testNumbers = new LinkedList<Integer>();
			testErrors = new LinkedList<ATestSuite.ErrorsTestSuite>();
		}
		
		public String getMessage() {
			return "["+ testErrors.size() + "] test(s) from " +
				ATests.class.getName() + " instance failed.";
		}
		
		/**
		 * Returns how many {@link ATestSuite}s failed while performing
		 * tests of a {@link ATests} instance.
		 * 
		 * @return Number of {@link ATestSuite}s failed.
		 */
		public int getNumberOfFailedTests() {
			return testNumbers.size();
		}
		
		/**
		 * Keep in mind that {@link ErrorsTests} objects are thrown if
		 * tests of a {@link ATests} instance are executed and fail:
		 * Returns the list position in the list of {@link ATestSuite}
		 * objects, of an {@link ATests} object, for the n'th failed
		 * {@link ATestSuite} of this {@link ErrorsTests} object.
		 * <br>
		 * Thus the result tells, which test suite of an 
		 * {@link ATests} instance failed, while executing a test of it.
		 * 
		 * @param nthFailedTest Position in the list of {@link ATestSuite.ErrorsTestSuite}s
		 * of this {@link ErrorsTests} instance.
		 * @return Position in the list of {@link ATestSuite}s of the
		 * {@link ATests} object.
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Returns the n'th failed {@link ATestSuite}'s exception contained
		 * in this {@link ErrorsTests} object.
		 * 
		 * @param nthFailedTest Position in the list of {@link ATestSuite.ErrorsTestSuite}s
		 * of this {@link ErrorsTests} instance.
		 * @return Exception thrown, while executing any of the test methods of
		 * a {@link ATestSuite}.
		 */
		public ATestSuite.ErrorsTestSuite getTestError(int nthFailedTest) {
			return testErrors.get(nthFailedTest);
		}
	}
}
