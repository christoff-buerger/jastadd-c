package org.testsuites;

/**
 * {@link ConfigurationException}s are thrown if the test
 * suite contains errors, thus it's tests can not be executed.
 * 
 * @author C. Bürger
 *
 */
public class ConfigurationException extends Exception {
	public static final long serialVersionUID = 1L;
	
	public ConfigurationException(String message) {
		super(message);
	}
	
	public ConfigurationException(Throwable exception) {
		super(exception);
	}
	
	public ConfigurationException(String message, Throwable exception) {
		super(message, exception);
	}
}
