package org.testsuites;

/**
 * {@link FailedTestException}s are thrown, if a test failed while
 * executing a test method.<br>
 * <br>
 * Each possible test case representation will derive it's own subclass
 * of {@link FailedTestException} to throw it's own exceptions if during the
 * execution of some of it's test methods a test failed. The
 * {@link FailedTestException} of a class will contain the
 * {@link FailedTestException} thrown by other test case representations used
 * during it's own tests.
 * <br>
 * Failed tests are no errors of the test suite. Errors are signaled
 * by {@link ConfigurationException}s.
 * 
 * @author C. Bürger
 *
 */
public class FailedTestException extends Exception {
	public static final long serialVersionUID = 1L;
	
	public FailedTestException() {
		super();
	}
	
	public FailedTestException(String message) {
		super(message);
	}
	
	public FailedTestException(Throwable exception) {
		super(exception);
	}
	
	public FailedTestException(String message, Throwable exception) {
		super(message, exception);
	}
}
