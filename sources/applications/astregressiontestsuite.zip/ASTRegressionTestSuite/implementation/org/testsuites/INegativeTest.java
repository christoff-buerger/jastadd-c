package org.testsuites;

/**
 * Interface representing a negative test.
 * 
 * @author C. Bürger
 *
 */
public interface INegativeTest {
	/**
	 * Executes the negative test represented by this {@link INegativeTest}.
	 * 
	 * @throws ConfigurationException Is thrown, if the test
	 * contains errors and it was not possible to do the test at all.
	 * @throws ErrorNegativeTest Is thrown, if the test failed.
	 */
	public void runTest() throws ConfigurationException, ErrorNegativeTest;
	
	/**
	 * This exceptions are thrown, if a negative test fails.
	 * 
	 * @author C. Bürger
	 *
	 */
	public abstract static class ErrorNegativeTest extends FailedTestException {
		final public static long serialVersionUID = 1L;
		public ErrorNegativeTest(String message, Exception exc) {super(message, exc);}
		public ErrorNegativeTest(String message) {super(message);}
		public ErrorNegativeTest(Exception exc) {super(exc);}
	}
}
