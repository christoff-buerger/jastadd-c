package org.testsuites;

import org.testsuites.INegativeTest.ErrorNegativeTest;

/**
 * Interface representing a positive test.
 * 
 * @author C. Bürger
 *
 */
public interface IPositiveTest {
	/**
	 * Executes the positive test represented by this {@link IPositiveTest}.
	 * 
	 * @throws ConfigurationException Is thrown, if the test
	 * contains errors and it was not possible to do the test at all.
	 * @throws ErrorNegativeTest Is thrown, if the test failed.
	 */
	public void runTest() throws ConfigurationException, ErrorPositiveTest;
	
	/**
	 * This exceptions are thrown, if a positive test fails.
	 * 
	 * @author C. Bürger
	 *
	 */
	public abstract static class ErrorPositiveTest extends FailedTestException {
		final public static long serialVersionUID = 1L;
		public ErrorPositiveTest(String message, Exception exc) {super(message, exc);}
		public ErrorPositiveTest(String message) {super(message);}
		public ErrorPositiveTest(Exception exc) {super(exc);}
	}
}
