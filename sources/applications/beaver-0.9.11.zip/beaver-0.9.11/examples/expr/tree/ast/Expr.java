package expr.tree.ast;

public abstract class Expr extends Node
{

}