                                       _BitmaskType-Generator_
                                             Version 1.1
                                          Christoff  Bürger
                                     Christoff.Buerger@gmail.com
                                          16th of May  2017
****************************************************************************************************

Synopsis: This package provides a simple compiler for the generation of highly optimised and easily
	compose- and expandable bit-field structures for _Java_. Given a set of size and
	composition specifications, _Java_ interfaces providing convenient access functions
	and respective implementation classes are generated. Bit-fields themselves are realised as
	consecutive chunks of memory; for optimal access aligned and packed ranges within shared
	byte-arrays. Mixing inheritance enables easy composition of bit-field specifications with
	optimal memory layout for each required combination.
	
                                              I. Usage
****************************************************************************************************

Sets of bitmask-type specifications can be compiled using the main method of
	`bitmasktypegenerator.Compiler`.
If called without arguments a help text will be printed describing command line arguments and usage.

_Apache Ant_ is supported via the class `bitmasktypegenerator.AntTask`. It expects an output
destination used as base directory for all generated bitmask-types and an _Ant_ `fileset`
representing the bitmask-type specifications to compile. For example,

```
<target name="My BitmaskType-Generator Ant configuration">
	<bitmasktypegenerator outdir="d:/output-directory">
		<fileset dir="d:/specifications-base-directory">
			<include name="**/*.type"/>
		</fileset>
	</bitmasktypegenerator>
</target>
```

will compile all `*.type` files in directory `d:/specifications-base-directory` or any of its
subdirectories. Bitmask-types will be generated in `d:/output-directory` and respective
subdirectories corresponding to the bitmask-type packages given in the compiled input
specifications. The _Ant_ `taskdef` for above task is:

```
<taskdef classname="bitmasktypegenerator.AntTask" name="bitmasktypegenerator">
	<classpath>
		<pathelement path="d:/required-libraries-directory/bitmasktypegenerator.jar"/>
		<pathelement path="D:/required-libraries-directory/beaver-rt.jar"/>
		<pathelement path="D:/required-libraries-directory/tuprolog.jar"/>
	</classpath>
</taskdef>
```

                                          II. Documentation
****************************************************************************************************

The syntax and semantics of bitmask-types specifications is described in
	`documentation/language-specification.txt`.

Examples are provided in the `examples` directory; they can be compiled using the `build.xml` _Ant_
build script. All results are generated in `examples/results-gen`.

                                          III. Requirements
****************************************************************************************************

The _BitmaskType-Generator_ requires _JRE 8_ and the following _Java_ libraries for execution:
 - _Beaver 0.9.11_: `beaver-rt.jar` (_BSD license_)
 - _tuProlog 2.1_: `tuprolog.jar` (_GNU LESSER GENERAL PUBLIC LICENSE_ version 2.1)

An executable `jar` can be generated using the `build.xml` _ANT_ script; it requires _ANT 1.7.0_.
Besides _JDK 8_, building requires:
 - _JFlex 1.6.1_ (_GPL license_)
 - _Beaver 0.9.11_ (_BSD license_)
 - _JastAdd2_ (_BSD license_)
 - _tuProlog 2.1_ (_GNU LESSER GENERAL PUBLIC LICENSE_ version 2.1)

All libraries (except the _JRE_/_JDK_) are provided in `sources/libraries`.

                                             IV. License
****************************************************************************************************

The license is given in `license.txt`.
