package bitmasktypegenerator;

import java.util.List;
import java.util.LinkedList;

import java.io.File;
import java.io.Reader;
import java.io.FileReader;

import org.apache.tools.ant.Task;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.DirectoryScanner;

/**
 * Ant task for the BitmaskType-Generator. A BitmaskType-Generator ant script
 * consists of an File object representing the destination directory to
 * print the generated Java classes to and a FileSet representing the specification
 * files to compile. The concrete file names and directories of the generated Java
 * classes depends on the packages and names of the BitmaskTypes given in the
 * specification files. The output destination is just the root directory for the
 * classes and packages to generate.
 * 
 * @author Christoff Bürger
 *
 */
public class AntTask extends Task {
	private File outputDestination;
	private List<File> sourceSpecifications;
	
	/**
	 * Constructor internally called by Ant.
	 */
	public AntTask() {
		this.outputDestination = null;
		this.sourceSpecifications = new LinkedList<File>();
	}
	
	/**
	 * Called by Ant to set the output destination based on the
	 * given Ant script.
	 * 
	 * @param outputDestination The root directory for the Java classes to print.
	 */
	public void setOutdir(File outputDestination) {
		this.outputDestination = outputDestination;
	}
	
	/**
	 * Called by Ant to set the specification files to compile based
	 * on the given Ant script.
	 * 
	 * @param sourceSpecifications Lists all the BitmaskType-Generator
	 * specifications to compile.
	 */
	public void addConfiguredFileSet(FileSet sourceSpecifications) {
		DirectoryScanner s = sourceSpecifications.getDirectoryScanner(getProject());
	    String[] files = s.getIncludedFiles();
	    String baseDir = s.getBasedir().getPath();
	    for(int i = 0; i < files.length; i++)
	    	this.sourceSpecifications.add(new File(baseDir + File.separator + files[i]));
	}
	
	/**
	 * Method called by Ant to execute an Ant script.
	 */
	public void execute() throws BuildException {
		try {
			System.err.println("Output directory: "+ outputDestination.getAbsolutePath());
			
			List<Reader> sourceReaders = new LinkedList<Reader>();
			List<String> sourceNames = new LinkedList<String>();
			for (File source:sourceSpecifications) {
				System.err.println("Source file: "+ source.getAbsolutePath());
				sourceReaders.add(new FileReader(source));
				sourceNames.add(source.getName());
			}
			
			Compiler.execute(outputDestination, sourceReaders, sourceNames);
		} catch (Exception exc) {
			throw new BuildException(exc);
		}
	}
}
