package bitmasktypegenerator;

import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.Reader;

import java.util.List;
import java.util.LinkedList;
import java.util.Iterator;

import java.util.logging.Logger;
import java.util.logging.FileHandler;
import java.util.logging.SimpleFormatter;
import java.util.logging.Level;

import bitmasktypegenerator.symbols.*;
import bitmasktypegenerator.syntax.*;
import bitmasktypegenerator.semantics.*;
import bitmasktypegenerator.backend.*;

/**
 * This class can be used to execute the BitmaskType-Generator with an arbitrary number
 * of source files as input. All source files given will form one CompilationUnit, thus
 * the source files may depend on each other. The generated output will be saved in the
 * current working directory as root directory, if no output directory is selected. Another
 * output directory can be selected by the arguments -d directory, where directory is the
 * directory to print the files to. The selected output directory is a root directory,
 * meaning that the actual output will be generated in sub directories corresponding
 * to the package names given for the BitmaskTypes to generate.
 * 
 * @author Christoff Bürger
 *
 */
public class Compiler {
	/**
	 * Logger used to log lexic, syntactic and semantic errors.
	 */
	public static Logger logger;
	
	private static void printInputStreamOnStandardOut(InputStream input) throws IOException {
		StringBuilder stringbuf = new StringBuilder();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
			input,
			"UTF-8"));
		char[] cbuf = new char[65536];
		while (true) {
			int read = reader.read(cbuf, 0, 65536);
			if (read < 0)
				break;
			stringbuf.append(cbuf, 0, read);
		}
		System.out.append(stringbuf);
	}
	
	/**
	 * The main method can be used to compile a set of BitmaskType-Generator
	 * specifications given by it's arguments. The arguments also configurate the
	 * BitmaskType-Generator.<br>
	 * <br>
	 * Call the main method without arguments to get a listing of it's permitted
	 * arguments and their semantics.<br>
	 * <br>
	 * Exceptions regarding problems to read a specification
	 * file to compile, to print result Java classes or wrong BitmaskType-Generator
	 * configurations are thrown and not logged. All problems regarding errors
	 * in specification files are logged and will not cause an exception to be
	 * thrown.
	 * 
	 * @throws Parser.Exception See above.
	 * @throws IOException See above.
	 */
	public static void main(String[] args) throws Parser.Exception, IOException {
		// If no arguments are given print a help message.
		if (args.length < 1) {
			final String corruptedError = "FATAL: Can't open help file.";
			InputStream usageInput =
				Compiler.class.getResourceAsStream("usage.txt");
			if (usageInput == null)
				throw new RuntimeException(corruptedError);
			printInputStreamOnStandardOut(usageInput);
			return;
		}
		
		File outputDestination = null;
		List<Reader> sourcesReader = new LinkedList<Reader>();
		List<String> sourcesNames = new LinkedList<String>();
		
		// Read the input arguments and configure the BitmaskType-Generator appropriate.
		for (int i = 0; i < args.length; i++) {
			if (args[i].startsWith("-d")) {
				if (outputDestination != null)
					throw new IllegalArgumentException(
						"Output destination allready specified.");
				if (args.length - 1 < ++i)
					throw new IllegalArgumentException(
						"Missing output destination.");
				outputDestination = new File(args[i]);
			} else if (args[i].equals("-license")) {
				InputStream licenseInput =
					Compiler.class.getResourceAsStream("license.txt");
				final String corruptedError = "FATAL: Can't open license file.";
				if (licenseInput == null)
					throw new RuntimeException(corruptedError);
				try {
					printInputStreamOnStandardOut(licenseInput);
				} catch (IOException exception) {
					throw new RuntimeException(corruptedError);
				}
				return;
			} else {
				File specification = new File(args[i]);
				sourcesReader.add(new FileReader(specification));
				sourcesNames.add(specification.getName());
			}
		}
		
		execute(outputDestination, sourcesReader, sourcesNames);
	}
	
	private static File checkOutputDestination(File outputDestination) {
		if (outputDestination == null)
			outputDestination = new File(".");
		if (!outputDestination.exists())
			throw new IllegalArgumentException(
				"Output destination "+
				outputDestination.getAbsolutePath() +
				" does not exist.");
		if (!outputDestination.isDirectory())
			throw new IllegalArgumentException(
				"Output destination "+
				outputDestination.getAbsolutePath() +
				" is no direstory.");
		return outputDestination;
	}
	
	/**
	 * Executes the BitmaskType-Generator to compile a set of specification files and
	 * print the result Java classes.<br>
	 * <br>
	 * For exception semantics see {@link #main(String[])}.
	 * 
	 * @param outputDestination The output directory the generated specification
	 * files based on the package and BitmaskTypes names given will be printed to. If
	 * null is given, the current working directory will be the output destination.
	 * @param sourcesReader A list of all the specifications to compile.
	 * @param sourcesNames A list of names associated with each specification.
	 * @throws Parser.Exception See {@link #main(String[])}.
	 * @throws IOException See {@link #main(String[])}.
	 */
	public static void execute(
		File outputDestination,
		List<Reader> sourcesReader,
		List<String> sourcesNames)
		throws Parser.Exception, IOException
	{
		outputDestination = checkOutputDestination(outputDestination);
		
		// Initialize the logger.
		logger = Logger.getLogger(Compiler.class.getPackage().getName());
		FileHandler fileHandler = new FileHandler(
			outputDestination + File.separator + "errors.log",
			0,
			1,
			false);
		fileHandler.setEncoding("UTF-8");
		fileHandler.setFormatter(new SimpleFormatter());
		fileHandler.setLevel(Level.SEVERE);
		logger.addHandler(fileHandler);
		
		// Build an AST for the input specifications gathered so far.
		Lexer lexer = new Lexer(sourcesReader, sourcesNames);
		Parser parser = new Parser();
		CompilationUnit result = (CompilationUnit)parser.parse(lexer);
		if (parser.errors.size() > 0) {
			for (SourceError error: parser.errors)
				logger.log(Level.SEVERE, error.getMessage());
			return;
		}
		
		// Validate the AST. Check semantic constraints. Print error messages.
		boolean isCorrect = result.isCorrect();
		Iterator<SourceError> errorIter = result.CollectErrors();
		while (errorIter.hasNext()) {
			logger.log(Level.SEVERE, (errorIter.next()).getMessage());
		}
		if (!isCorrect)
			return;
		
		// Generate the result BitmaskTypes.
		BitmaskTypeCodePrinter printer = new BitmaskTypeCodePrinter();
		for (Object type: result.DefinedBitmaskTypes()) {
			printer.generateCode(outputDestination, (BitmaskType)type);
		}
	}
}
