package bitmasktypegenerator;

/**
 * Class representing BitmaskType specification errors. SourceError's are
 * no exception in the sense that the BitmaskType-Generator doesn't work
 * properly or it's configuration is false. They represent errors in specification
 * files the BitmaskType-Generator has/tried to compile.
 * 
 * @author Christoff Bürger
 *
 */
public class SourceError extends Exception implements Comparable<SourceError> {
	public static final long serialVersionUID = 1L;
	
	/**
	 * Each SourceError is associated with a compilation phase the error occurred.
	 * 
	 * @author C. Bürger
	 *
	 */
	public enum ErrorType {LEXICAL, SYNTACTICAL, SEMANTICAL};
	
	public ErrorType errorType;
	public Integer line;
	public Integer column;
	public String sourceName;
	
	public SourceError(String message) {
		super(message);
		line = null;
		column = null;
	}
	
	public SourceError(String message, Exception exception) {
		super(message, exception);
		line = null;
		column = null;
	}
	
	public SourceError(Exception exception) {
		super(exception);
		line = null;
		column = null;
	}
	
	public String getMessage() {
		StringBuilder errorM = new StringBuilder();
		errorM.append('(');
		errorM.append(sourceName);
		errorM.append(':');
		errorM.append(line);
		errorM.append(';');
		errorM.append(column);
		errorM.append(')');
		errorM.append(' ');
		errorM.append(super.getMessage());
		return errorM.toString();
	}
	
	public int compareTo(SourceError o) {
		if (errorType == ErrorType.LEXICAL) {
			if (o.errorType == ErrorType.SEMANTICAL ||
					o.errorType == ErrorType.SYNTACTICAL)
				return -1;
		} else if (errorType ==  ErrorType.SYNTACTICAL) {
			if (o.errorType == ErrorType.LEXICAL)
				return 1;
			else if (o.errorType == ErrorType.SEMANTICAL)
				return -1;
		} else {
			if (o.errorType == ErrorType.LEXICAL ||
					o.errorType ==  ErrorType.SYNTACTICAL)
				return 1;
		}
		if (line != o.line)
			return line - o.line;
		if (column != o.column)
			return column - o.column;
		return getMessage().compareTo(o.getMessage());
	}
	
	public boolean equals(Object o) {
		if (!(o instanceof SourceError))
			return false;
		
		return compareTo((SourceError)o) == 0;
	}
}
