package bitmasktypegenerator.backend;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Date;
import java.util.TimeZone;

import java.text.SimpleDateFormat;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import bitmasktypegenerator.semantics.*;

/**
 * Class used to print the resulting Java classes of a successful BitmaskType-Generator
 * specification compilation. The class expects a correct, statically evaluated AST
 * representing a BitmaskType.
 * 
 * @author Christoff Bürger
 *
 */
public class BitmaskTypeCodePrinter {
	public boolean overwrite = true;
	
	/**
	 * Generates the Java code resulting from a correct BitmaskType specification.
	 * Exceptions are only thrown, if the Java source code to generate can not be
	 * printed.
	 * 
	 * @param outputDestination The base directory to print the generated Java source
	 * code files to. The exact source code file names and subdirectories depend on the
	 * BitmaskType names and packes in the specification file.
	 * 
	 * @param type AST of a BitmaskType.
	 * @throws IOException Is thrown, if the result file can not be printed.
	 */
	public void generateCode(File outputDestination, BitmaskType type) throws IOException {
		if (type == null)
			return;
		if (outputDestination == null)
			throw new RuntimeException("No outputDestination given.");
		
		if (type.hasInterfaceName()) {
			StringBuilder destinationName =
				new StringBuilder(outputDestination.getAbsolutePath());
			destinationName.append(File.separatorChar);
			destinationName.append(
					type.getInterfaceName().ResolvePackage().replace(
							'.', File.separatorChar));
			
			File destination = new File(destinationName.toString());
			if (!destination.exists()) {
				destination.mkdir();
			}
			
			destinationName.append(
					File.separatorChar);
			destinationName.append(type.getInterfaceName().ClassValue());
			destinationName.append(".java");
			
			destination = new File(destinationName.toString());
			if (destination.exists() && !overwrite) {
				StringBuilder errorM = new StringBuilder();
				errorM.append("BitmaskType: generating [");
				errorM.append(type.getInterfaceName().ResolveName());
				errorM.append("].\n\tFile [");
				errorM.append(destination.getAbsolutePath());
				errorM.append("] allready exists.");
				throw new IOException(errorM.toString());
			}
			
			FileWriter out;
			try {
				out = new FileWriter(destination);
				generateInterfaceCode(out, type);
				out.close();
			} catch (IOException exc) {
				StringBuilder errorM = new StringBuilder();
				errorM.append("BitmaskType: generating [");
				errorM.append(type.getInterfaceName().ResolveName());
				errorM.append("].\n\tCan't print file [");
				errorM.append(destination.getAbsolutePath());
				errorM.append("].\n\tIOException: ");
				errorM.append(exc.getMessage());
				throw new IOException(errorM.toString());
			}
		} if (type.hasConcreteName()) {
			StringBuilder destinationName =
				new StringBuilder(outputDestination.getAbsolutePath());
			destinationName.append(File.separatorChar);
			destinationName.append(
					type.getConcreteName().ResolvePackage().replace(
							'.', File.separatorChar));
			
			File destination = new File(destinationName.toString());
			if (!destination.exists()) {
				destination.mkdir();
			}
			
			destinationName.append(
					File.separatorChar);
			destinationName.append(type.getConcreteName().ClassValue());
			destinationName.append(".java");
			
			destination = new File(destinationName.toString());
			if (destination.exists() && !overwrite) {
				StringBuilder errorM = new StringBuilder();
				errorM.append("BitmaskType: generating [");
				errorM.append(type.getConcreteName().ResolveName());
				errorM.append("].\n\tFile [");
				errorM.append(destination.getAbsolutePath());
				errorM.append("] allready exists.");
				throw new IOException(errorM.toString());
			}
			
			FileWriter out;
			try {
				out = new FileWriter(destination);
				generateConcreteCode(out, type);
				out.close();
			} catch (IOException exc) {
				StringBuilder errorM = new StringBuilder();
				errorM.append("BitmaskType: generating [");
				errorM.append(type.getConcreteName().ResolveName());
				errorM.append("].\n\tCan't print file [");
				errorM.append(destination.getAbsolutePath());
				errorM.append("].\n\tIOException: ");
				errorM.append(exc.getMessage());
				throw new IOException(errorM.toString());
			}
		}
	}
	
	private void generateInterfaceCode(FileWriter out, BitmaskType type) throws IOException {
		out.append("package ");
		out.append(type.getInterfaceName().ResolvePackage());
		out.append(";\n\n");
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		dateFormat.setTimeZone(TimeZone.getDefault());
		
		out.append("/**\n * Generated interface BitmaskType (");
		out.append(type.SourceName());
		out.append(": ");
		out.append(dateFormat.format(date));
		out.append(").\n */\npublic interface ");
		out.append(type.getInterfaceName().ClassValue());
		if (type.getNumCombinedType() > 0) {
			out.append("\nextends ");
		} for (int i = 0; i < type.getNumCombinedType(); i++) {
			if (i > 0) {
				out.append(",\n\t\t");
			}
			out.append(type.getCombinedType(i).ResolveName());
		}
		out.append(" {\n\n");
		
		HashMap typedAttributes = type.TypedAttributes();
		Iterator tAttIter = typedAttributes.values().iterator();
		while (tAttIter.hasNext()) {
			TypedAttribute tAtt = (TypedAttribute)tAttIter.next();
			final String tAttName = tAtt.getAttributeName().getTerminal();
			final String tAttType = tAtt.getType().ResolveName();
			
			out.append("// Typed attribute '");
			out.append(tAttName);
			out.append("' (");
			out.append(tAtt.SourceName());
			out.append(':');
			out.append(Integer.toString(tAtt.Line()));
			out.append(';');
			out.append(Integer.toString(tAtt.Column()));
			out.append(")\n\tpublic ");
			out.append(tAttType);
			out.append(' ');
			out.append(tAttName);
			out.append(" ();\n\tpublic void ");
			out.append(tAttName);
			out.append("(Object value);\n\n");
		}
		
		HashMap bitfieldAttributes = type.BitfieldAttributes();
		Iterator bAttIter = bitfieldAttributes.values().iterator();
		while (bAttIter.hasNext()) {
			BitfieldAttribute bAtt = (BitfieldAttribute)bAttIter.next();
			final String bAttName = bAtt.getAttributeName().getTerminal();
			
			out.append("// Bitfield attribute '");
			out.append(bAttName);
			out.append("' (");
			out.append(bAtt.SourceName());
			out.append(':');
			out.append(Integer.toString(bAtt.Line()));
			out.append(';');
			out.append(Integer.toString(bAtt.Column()));
			out.append(")\n\tpublic int ");
			out.append(bAttName);
			out.append("();\n\tpublic boolean ");
			out.append(bAttName);
			out.append("IsNull();\n\tpublic void ");
			out.append(bAttName);
			out.append("(int value);\n\tpublic void ");
			out.append(bAttName);
			out.append("SetOne();\n\tpublic void ");
			out.append(bAttName);
			out.append("Clear();\n\n");
		}
		
		out.append("}\n");
	}
	
	private void generateConcreteCode(FileWriter out, BitmaskType type) throws IOException {
		out.append("package ");
		out.append(type.getConcreteName().ResolvePackage());
		out.append(";\n\n");
		
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		dateFormat.setTimeZone(TimeZone.getDefault());
		
		out.append("/**\n * Generated concrete BitmaskType (");
		out.append(type.SourceName());
		out.append(": ");
		out.append(dateFormat.format(date));
		out.append(").\n */\npublic class ");
		out.append(type.getConcreteName().ClassValue());
		if (type.hasExtendedType()) {
			out.append("\nextends ");
			out.append(type.getExtendedType().ResolveName());
		}
		if (type.hasInterfaceName()) {
			out.append("\nimplements ");
			out.append(type.getInterfaceName().ResolveName());
		} else {
			if (type.getNumCombinedType() > 0) {
				out.append("\nimplements ");
			} for (int i = 0; i < type.getNumCombinedType(); i++) {
				if (i > 0) {
					out.append(",\n\t\t");
				}
				out.append(type.getCombinedType(i).ResolveName());
			}
		}
		out.append(" {\n\n");
		
		List codes = type.CodeFragments();
		if (codes.size() > 0)
			out.append("\t/*\n\t * User specified code fragments.\n\t */");
		Iterator codeIter = codes.iterator();
		while (codeIter.hasNext()) {
			Code code = (Code)codeIter.next();
			out.append(code.getCode().getTerminal());
			out.append('\n');
		}
		if (codes.size() > 0) {
			out.append("\t/* \n\t * End user specified code fragments.\n\t */\n\n");
		}
		
		int typedAttributesCounter = 0;
		HashMap typedAttributes = type.TypedAttributes();
		Iterator tAttIter = typedAttributes.values().iterator();
		while (tAttIter.hasNext()) {
			TypedAttribute tAtt = (TypedAttribute)tAttIter.next();
			final String tAttName = tAtt.getAttributeName().getTerminal();
			final String tAttType = tAtt.getType().ResolveName();
			
			out.append("// Typed attribute '");
			out.append(tAttName);
			out.append("' (");
			out.append(tAtt.SourceName());
			out.append(':');
			out.append(Integer.toString(tAtt.Line()));
			out.append(';');
			out.append(Integer.toString(tAtt.Column()));
			out.append(")\n\tprivate ");
			out.append(tAttType);
			out.append(" _value");
			out.append(Integer.toString(typedAttributesCounter));
			out.append(";\n\tpublic ");
			out.append(tAttType);
			out.append(' ');
			out.append(tAttName);
			out.append(" () {\n\t\treturn _value");
			out.append(Integer.toString(typedAttributesCounter));
			out.append(";\n\t}\n\tpublic void ");
			out.append(tAttName);
			out.append("(Object value) {\n\t\t_value");
			out.append(Integer.toString(typedAttributesCounter));
			out.append(" = (");
			out.append(tAttType);
			out.append(")value;\n\t}\n\n");
			
			typedAttributesCounter++;
		}
		
		/* 
		 * IMPORTANT: All bit operators in Java work on int or long integers,
		 * thus the integer types byte, short and char are implicit casted to int [5.6.1].
		 * int integers have 32bit in Java.
		 */
		int storageUnitCounter = 0;
		StringBuilder packingCommentCode = new StringBuilder();
		List packing = type.Packing();
		Iterator packingIter = packing.iterator();
		while (packingIter.hasNext()) {
			packingCommentCode.append("\n\t * \t[");
			
			List unit = (List)packingIter.next();
			Iterator unitIter = unit.iterator();
			StringBuilder additionalStorageUnitsRequiredComment = new StringBuilder();
			int unitPosition = 0;
			int numberOfAdditionalStorageUnitsRequired = 0;
			while (unitIter.hasNext()) {
				final int storageUnitSizeInBit = type.StorageUnitSize();
				final int storageUnitSizeMask = (int)Math.pow(2, storageUnitSizeInBit) - 1;
				final BitfieldAttribute bAtt = (BitfieldAttribute)unitIter.next();
				final int completeBAttSize = bAtt.getSize().getTerminal();
				int bAttSizeInUnit = completeBAttSize % storageUnitSizeInBit;
				if (bAttSizeInUnit == 0)
					bAttSizeInUnit = storageUnitSizeInBit;
				final String bAttName = bAtt.getAttributeName().getTerminal();
				final int unitsBAttNeeds =
					(int)Math.ceil(new Double(completeBAttSize) / storageUnitSizeInBit);
				final int toShiftInUnitPosition =
					storageUnitSizeInBit - (unitPosition + bAttSizeInUnit);
				final int significantValuePartInUnit =
					(int)Math.pow(2, bAttSizeInUnit) - 1;
				final int thisBAttsPartInUnionMask =
					significantValuePartInUnit << toShiftInUnitPosition;
				final int otherPartsInUnitMask =
					storageUnitSizeMask - thisBAttsPartInUnionMask;
				
				
				out.append("// Bitfield attribute '");
				out.append(bAttName);
				out.append("' (");
				out.append(bAtt.SourceName());
				out.append(':');
				out.append(Integer.toString(bAtt.Line()));
				out.append(';');
				out.append(Integer.toString(bAtt.Column()));
				out.append(")\n");
				
				/*
				 * public int Attribute()
				 */
				out.append("\tpublic int ");
				out.append(bAttName);
				out.append("() {\n\t\treturn ");
				if (toShiftInUnitPosition != 0)
					out.append('(');
				out.append("field[");
				out.append(Integer.toString(storageUnitCounter));
				out.append("]");
				if (toShiftInUnitPosition != 0) {
					out.append(" >>> ");
					out.append(Integer.toString(toShiftInUnitPosition));
					out.append(')');
				}
				out.append(" & 0x");
				out.append(Integer.toHexString(significantValuePartInUnit));
				StringBuilder additionalValueSettingCode = new StringBuilder();
				for (int i = 1; i < unitsBAttNeeds; i++) {
					numberOfAdditionalStorageUnitsRequired++;
					
					out.append("\n\t\t\t| (field[");
					out.append(Integer.toString(storageUnitCounter +
							numberOfAdditionalStorageUnitsRequired));
					out.append("] & 0x");
					out.append(Integer.toHexString(storageUnitSizeMask));
					out.append(") << ");
					out.append(Integer.toString(storageUnitSizeInBit * i));
					
					additionalValueSettingCode.append("\n\t\tfield[");
					additionalValueSettingCode.append(Integer.toString(storageUnitCounter +
							numberOfAdditionalStorageUnitsRequired));
					additionalValueSettingCode.append("] = (byte)(value >>> ");
					additionalValueSettingCode.append(Integer.toString(storageUnitSizeInBit * i));
					additionalValueSettingCode.append(");");
					
					additionalStorageUnitsRequiredComment.append("\n\t * \t[(");
					additionalStorageUnitsRequiredComment.append(bAttName);
					additionalStorageUnitsRequiredComment.append(';');
					additionalStorageUnitsRequiredComment.append("continue)]");
				}
				out.append(";\n\t}\n");
				
				/*
				 * public void Attribute(int value)
				 */
				out.append("\tpublic void ");
				out.append(bAttName);
				out.append("(int value) {");
				if (completeBAttSize < 32) { // 32 as value is of type int
					out.append("\n\t\tif((value & 0x");
					out.append(Integer.toHexString(
							~((int)Math.pow(2, completeBAttSize) - 1)));
					out.append(") != 0)\n\t\t\tthrow new NumberFormatException(");
					out.append("\n\t\t\t\t\"Value [\"+ value +\"] for bitfield attribute [");
					out.append(bAttName);
					out.append("] out of range.\"+");
					out.append("\n\t\t\t\t\"\\n\\tThe bitfield attribute's size is only [");
					out.append(Integer.toString(completeBAttSize));
					out.append("] bit.\");");
				}
				out.append("\n\t\tfield[");
				out.append(Integer.toString(storageUnitCounter));
				out.append("] = ");
				if (otherPartsInUnitMask != 0) {
					out.append("(byte)((field[");
					out.append(Integer.toString(storageUnitCounter));
					out.append("] & 0x");
					out.append(Integer.toHexString(otherPartsInUnitMask));
					out.append(") | ");
					if (toShiftInUnitPosition != 0)
						out.append('(');
					out.append("(value & 0x");
					out.append(Integer.toHexString(significantValuePartInUnit));
					out.append(')');
					if (toShiftInUnitPosition != 0) {
						out.append(" << ");
						out.append(Integer.toString(toShiftInUnitPosition));
						out.append(')');
					}
					out.append(");");
				} else {
					out.append("(byte)value;");
				}
				out.append(additionalValueSettingCode);
				out.append("\n\t}");
				
				/*
				 * public boolean AttributeIsNull()
				 */
				out.append("\n\tpublic boolean ");
				out.append(bAttName);
				out.append("IsNull() {return ");
				out.append(bAttName);
				out.append("() == 0;");
				out.append("}\n");
				
				/*
				 * public void AttributeSetOne()
				 */
				out.append("\tpublic void ");
				out.append(bAttName);
				out.append("SetOne() {");
				out.append(bAttName);
				out.append("(1);}\n");
				
				/*
				 * public void AttributeClear()
				 */
				out.append("\tpublic void ");
				out.append(bAttName);
				out.append("Clear() {");
				out.append(bAttName);
				out.append("(0);}\n\n");
				
				unitPosition = unitPosition + bAttSizeInUnit;
				
				packingCommentCode.append('(');
				packingCommentCode.append(bAttName);
				packingCommentCode.append(';');
				packingCommentCode.append(completeBAttSize);
				packingCommentCode.append(')');
			}
			packingCommentCode.append(']');
			packingCommentCode.append(additionalStorageUnitsRequiredComment);
			storageUnitCounter =
				storageUnitCounter + numberOfAdditionalStorageUnitsRequired + 1;
		}
		
		if (storageUnitCounter > 0) {
			out.append("\t/**\n\t * The bitfield attributes are:");
			out.append(packingCommentCode.toString());
			out.append("\n\t */\n\tprivate byte[] field = new byte[");
			out.append(Integer.toString(storageUnitCounter));
			out.append("];\n\n");
		}
		
		out.append("}\n");
	}
}
