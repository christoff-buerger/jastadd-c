%IMPORTANT: As attribute names have to be unique, the word set will be used.
%	Thus, we expect that there never occurs a list of attribute names
%	containing the same name several times.
%IMPORTANT: We also expect all attribute sizes to be <= the unit size. If there
%	are attributes with sizes greater than the unit size, they will occupy
%	at least one complete storage unit. Thus their size can be prepared
%	before calling the following predicates by setting it for the
%	prolog computation to: originalsize % unitsize. Thus for such an
%	attribute it's prolog fact representation will be
%	attribute(attributeName, originalsize % unitsize).
%	Attributes, which originalsize % unitsize = 0 have not to be
%	considered at all for packing optimization. Thus they must not occur
%	as fact in this prolog program.

%packing: Computes a packing. The semantics are the same like for freepacking.
%AL	...attribute list
%NAL	...new attribute list
%P	...packing
%FUP	...full packing
%FRP	...free packing
%COSTS	...unused bits
packing(P,AL,COSTS) :- fullpacking(FUP,AL,NAL), freepacking(FRP,NAL,COSTS), append(FUP,FRP,P).

%freepacking: Computes a packing for a set of attributes. The result is a set
%	of subsets. All the attributes of the input set will be packed, thus
%	each attribute will occur in exactly one subset. But the subsets may
%	contain unused bits.
%AL	...attribute list
%NAL	...new attribute list
%SC	...subset combination
%P	...packing
%NP	...new packing
%COSTS	...unused bits
%SCCOSTS...costs of one subset (subset combination costs)
%RPCOSTS...costs for the subsets not considered so far (rest packing costs)
freepacking([],[],0).
freepacking(NP,AL,COSTS) :- freecombine(SC,0,AL,SCCOSTS,NAL), freepacking(P,NAL,RPCOSTS), COSTS is SCCOSTS + RPCOSTS, append(P,[SC],NP).

%freecombine: Computes a combination of attributes from a given set.
%	The computed combination fills maximal one bitfield, but the
%	bitfield may contain unused bits.
%A	...attribute
%AL	...attribute list
%NAL	...new attribute list
%RAL	...rest attribute list
%CS	...combined size/current size
%AS	...attribute size
%NCS	...new combined size/new current size
%US	...unit size
%COSTS	...unused bits
freecombine([A],CS,AL,COSTS,NAL) :- member(A,AL), attribute(A,AS), unitsize(US), NCS is CS + AS, NCS < US + 1, delete(A,AL,NAL), COSTS is US - NCS.
freecombine([A|R],CS,AL,COSTS,RAL) :- member(A,AL), attribute(A,AS), unitsize(US), NCS is CS + AS, NCS < US + 1, delete(A,AL,NAL), freecombine(R,NCS,NAL,COSTS,RAL).

%fullpacking: Computes a full fitting packing for a set of attributes.
%	A full packing for a set of attributes is a set of subsets of
%	attributes. Each subset's size modulo the unit size is 0
%	(attributessize(subset) % unitsize = 0). An attribute will occur maximal
%	in one subset. Not all attributes of the input set have to occur in
%	result subsets.
%AL	...attribute list
%NAL	...new attribute list
%RAL	...rest attribute list
%P	...packing
%NP	...new packing
%C	...bitfield combination
fullpacking([],AL,AL).
fullpacking(NP,AL,RAL) :- fullcombine(C,0,AL,NAL), fullpacking(P,NAL,RAL), append(P,[C],NP).

%fullcombine: Computes a combination of attributes from a given set.
%	The computed combination fills exactly one bitfield unit (unitsize).
%US	...unit size
%S	...size
fullcombine([],US,AL,AL) :- unitsize(US).
%A	...attribute
%AL	...attribute list
%NAL	...new attribute list
%RAL	...rest attribute list
%CS	...combined size/current size
%AS	...attribute size
%NCS	...new combined size/new current size
%US	...unit size
fullcombine([A|R],CS,AL,RAL) :- unitsize(US), member(A,AL), attribute(A,AS), checkboundaryconstraint(A,CS,AS,US), delete(A,AL,NAL), NCS is CS + AS, combine(R,NCS,NAL,RAL).
