package bitmasktypegenerator.symbols;

import java.util.Iterator;
import java.util.List;

import java.io.Reader;

import beaver.Symbol;

import bitmasktypegenerator.syntax.Parser;

/**
 * Lexer for the BitmaskType-Generator. The lexer can handle several sources, which
 * form one logical compilation unit. This is needed as BitmaskType specifications
 * may depend on each other. E.g.:<br>
 * <br>
 * source file 1) it IType { Att1 Att2:3 Att3 }<br>
 * source file 2) ct EType it IEType cb IType { Att1:5 Att4 }<br>
 * <br>
 * Here the type in source file 2 combines the type of source file 1.
 * 
 * @author Christoff Bürger
 *
 */
public class Lexer extends beaver.Scanner {
	private Iterator<? extends Reader> inputReaderIter;
	private Iterator<String> inputNamesIter;
	private UnitLexer lexer;
	private String currentName;
	
	/**
	 * Constructs a lexer, initialized with a set of input specifications to scan and
	 * the names associated with each input specification.
	 * 
	 * @param inputReader The BitmaskType-Generator specifications to scan.
	 * @param associatedNames The names associated with the specifications to scan.
	 */
	public Lexer(List<? extends Reader> inputReader, List<String> associatedNames) {
		if (inputReader == null)
			throw new RuntimeException("Lexer: No input specifications selected.");
		if (associatedNames == null)
			throw new RuntimeException("Lexer: No input specification names selected.");
		if (inputReader.size() != associatedNames.size())
			throw new RuntimeException(
					"Lexer: The number of input reader sources must equal the number of their associated names.");
		
		this.inputReaderIter = inputReader.iterator();
		this.inputNamesIter = associatedNames.iterator();
		
		if (this.inputReaderIter.hasNext()) {
			lexer = new UnitLexer(this.inputReaderIter.next());
			currentName = null;
		} else throw new RuntimeException("Lexer: No BitmaskGenerator specification to compile selected.");
	}
	
	/**
	 * Delivers the next token for the parser.
	 * 
	 * @throws java.io.IOException Is thrown if the input can not be read.
	 * @throws UnknownTokenException Is thrown, if the specification file is not correct, thus
	 * contains unknown lexems.
	 */
	public Symbol nextToken() throws java.io.IOException, UnknownTokenException {
		if (currentName == null) { // Will only be called once, at the beginning of the lexical analysis.
			currentName = inputNamesIter.next();
			return new Symbol(Parser.Terminals.kTUNIT, currentName);
		}
		
		Symbol result = lexer.nextToken();
		
		if (result.getId() == Parser.Terminals.kTUNIT) {
			return new Symbol(Parser.Terminals.kTUNIT, currentName);
		} else if (result.getId() == Parser.Terminals.EOF) {
			if (inputReaderIter.hasNext()) {
				lexer.yyreset(inputReaderIter.next());
				currentName = inputNamesIter.next();
				return new Symbol(Parser.Terminals.kTUNIT, currentName);
			} else return result; // EOF is returned, as there's no more input specification.
		}
		return result; // An arbitrary token of the current input specification except EOF and kTUNIT is returned.
	}
}
