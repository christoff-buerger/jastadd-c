package bitmasktypegenerator.symbols;

import beaver.Scanner;

/**
 * UnknownTokenException's are thrown, if while lexing unknown lexems are
 * encountered. It's important to distinguish this type of error while parsing
 * from others, because it's the only possible lexical error caused by faulty
 * source code. Other errors during the lexical analyze are technical based,
 * like trying to read not existing source code files, not being allowed to
 * read a source code file, buffer problems etc. Exceptions like this should
 * never be instances of UnknownTokenException.<br>
 * <br>
 * Technical based exceptions are represented by {@link java.io.IOException}s.
 * 
 * @author Christoff Bürger
 *
 */
public class UnknownTokenException extends Scanner.Exception {
	final public static long serialVersionUID = 1L;
	
	public String unknownLexem;
	
	public UnknownTokenException(int line, int column, String unknownLexem, String message) {
		super(line, column, "Lexer error: " + message);
		
		this.unknownLexem = unknownLexem;
	}
	
	public UnknownTokenException(int line, int column, String unknownLexem) {
		super(line, column, "Lexer error: Unknown lexical element "+
				unknownLexem +" at ("+ line +";"+ column +").");
		
		this.unknownLexem = unknownLexem;
	}
}
