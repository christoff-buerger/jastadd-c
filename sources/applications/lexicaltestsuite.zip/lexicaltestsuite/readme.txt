                        LEXICAL TEST SUITE
                           Version 1.02
                     Author : Christoff Bürger
                     Christoff.Buerger@gmx.net
                            26.03.2008
********************************************************************

This application represents a lexical test suite useful to validate
scanner/lexer behavior. For arbitrary scanners test cases can be
specified using xml files. The lexical test suite reads and
executes such test cases. If tests fail, an error log file can be
printed or/and an arbitrary failed test handler (IResultHandler) can
be used. The lexical test suite can be configured using an
IConfiguration implementation supported by the user. This way
arbitrary scanner can be adapted to test them with the test suite.

A test case consists of positive and negative tests. Negative tests
have to result in an error while lexical analyse, e.g. if the source
code contains an unknown lexem. Positive tests have to result in a
list of recognized token, together with their corresponding lexems,
by the scanner.

The xml test files form a regression test suite, allowing
incremental scanner development and extension.

******************************* USAGE ******************************

The 'usage.txt' file describes how to use the lexical test suite
from command line. If the lexical test suite is used from command
line and no parameters are given a help message will be printed on
the standard output.

The lexical test suite also supports ant. How to develop ant
scripts, which use the lexical test suite the scripts of the
examples can be consulted.

*************************** DOCUMENTATION **************************

For further documentation check the javadoc. Also sample xml test
files and build scripts for a C99 lexer exist.

****************************** CONTENTS ****************************

The following directories are part of this test suite distribution :
 src 				: Contains the source code
 documentation 		: Contains the the javadoc
 sources\libraries 	: Contains distributions for each library needed
 					  by the lexical test suite.
 examples			: Contains sample xml test files

************************* LIBRARIES NEEDED *************************

The lexical test suite requires the following libraries :
 - jdom 1.1			(Apache-style open source license,
 					 with the acknowledgment clause removed; similar
 					 to the BSD-license)
 - ant 1.7.0		(Apache Software License Version 2.0)

Each library has it's own license.

****************************** LICENSE *****************************

A file called License.txt is supported with the lexical test suite.
The license of the lexical test suite is the license described in
the License.txt file.
