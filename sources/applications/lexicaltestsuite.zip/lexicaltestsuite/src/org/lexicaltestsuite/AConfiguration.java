package org.lexicaltestsuite;

/**
 * A default {@link IConfiguration} appropriate for most lexical test
 * suite configurations. Only the {@link #getLexerAdapter()} method still has to
 * be implemented, thus only the association with a scanner has to be implemented
 * in sub classes.
 * 
 * @author C. Bürger
 *
 */
public abstract class AConfiguration implements IConfiguration {
	/**
	 * Instantiates this configuration using the default result handler (
	 * {@link ResultPrinter}) of the lexical test suite to
	 * handle failed tests. The result printer uses the lexical test suites
	 * logger {@link Main#logger}.<br>
	 * <br>
	 * <b>Beware:</b> A logger must always be selected before starting the tests.
	 */
	public AConfiguration() {}
	
	/**
	 * Returns a {@link ResultPrinter} used, to handle failed lexical
	 * tests.
	 * 
	 * @return An new {@link ResultPrinter} instance.
	 */
	public IResultHandler createResultHandler() {
		return new ResultPrinter(Main.logger);
	}

	public abstract ILexerAdapter getLexerAdapter();
}
