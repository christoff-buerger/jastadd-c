package org.lexicaltestsuite;

import java.io.File;

import java.util.List;
import java.util.LinkedList;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.apache.tools.ant.types.FileSet;
import org.apache.tools.ant.DirectoryScanner;

/**
 * Ant task for the lexical test suite. For details about the parameters
 * check the usage.text file.
 * 
 * @author C. Bürger
 *
 */
public class AntTask extends Task {
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected java.lang.Class<?> configurationClass;
	
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected List<File> tests;
	
	/**
	 * For details about the parameter check the usage.txt file
	 */
	protected File loggingFile;
	
	/**
	 * Constructor internally called by Ant.
	 */
	public AntTask() {
		tests = new LinkedList<File>();
		configurationClass = null;
		loggingFile = null;
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setConfiguration(java.lang.Class<?> configurationClass) {
		this.configurationClass = configurationClass;
	}
	
	/**
	 * Called by Ant to set the specification files to compile based
	 * on the given Ant script.
	 * 
	 * @param sourceSpecifications Lists all the BitmaskType-Generator
	 * specifications to compile.
	 */
	public void addConfiguredFileSet(FileSet sourceSpecifications) {
		DirectoryScanner s = sourceSpecifications.getDirectoryScanner(getProject());
	    String[] files = s.getIncludedFiles();
	    String baseDir = s.getBasedir().getPath();
	    for(int i = 0; i < files.length; i++)
	    	this.tests.add(new File(baseDir + File.separator + files[i]));
	}
	
	/**
	 * Called by Ant (for details about the parameter check the usage.txt file).
	 */
	public void setLog(File loggingFile) {
		this.loggingFile = loggingFile;
	}
	
	/**
	 * Method called by Ant to execute an Ant script.
	 */
	public void execute() throws BuildException {
		try {
			Main.execute(configurationClass, tests, loggingFile);
		} catch(ConfigurationException exc) {
			throw new BuildException(exc);
		}
	}
}
