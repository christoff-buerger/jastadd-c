package org.lexicaltestsuite;

/**
 * {@link ConfigurationException}s are thrown if the lexical test suite
 * contains errors. E.g. if it's configuration isn't correct or xml
 * test files are incorrect. They are not thrown if tests failed, which is
 * the responsibility of {@link FailedTestException}s.
 * 
 * @author C. Bürger
 *
 */
public class ConfigurationException extends Exception {
	public static final long serialVersionUID = 1L;
	
	public ConfigurationException(String message) {
		super(message);
	}
	
	public ConfigurationException(Throwable exception) {
		super(exception);
	}
	
	public ConfigurationException(String message, Throwable exception) {
		super(message, exception);
	}
}
