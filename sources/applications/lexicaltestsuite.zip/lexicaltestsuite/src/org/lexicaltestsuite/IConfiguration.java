package org.lexicaltestsuite;

/**
 * Interface used for lexical test suite configurations.
 * A lexical test suite configuration describes :<br>
 *  - the lexer to use<br>
 *  - the handler handling failed lexical tests
 *  
 * @author C. Bürger
 *
 */
public interface IConfiguration {
	/**
	 * Returns the lexer to use to perform all lexical tests. It has to implement
	 * the {@link ILexerAdapter} interface, so most times it will be
	 * an adapter wrapping the real lexer used.
	 * 
	 * @return The lexer to test.
	 */
	public ILexerAdapter getLexerAdapter();
	
	/**
	 * Returns the {@link IResultHandler} to use to handle
	 * failed tests. The handler returned will be automatically used by
	 * the lexical test suite to handle all failed tests.<br>
	 * <br>
	 * Most handler will print some error log for all failed tests.
	 * 
	 * @return The default handler to use, to log failed tests.
	 */
	public IResultHandler createResultHandler();
}
