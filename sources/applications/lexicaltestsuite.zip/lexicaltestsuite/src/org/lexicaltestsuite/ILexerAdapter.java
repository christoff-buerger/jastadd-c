package org.lexicaltestsuite;

import java.io.Reader;

/**
 * Interface lexers, tested by the lexical test suite, have to implement.
 * The lexical test suite interacts with lexers only using this interface. As an
 * arbitrary lexer usually does not implement this interface, most times the lexer
 * has to be adapted against it, using a wrapper class. To keep the dependency
 * between lexer and test suite as low as possible, all parts of the lexical test
 * suite will only access the lexer using a
 * {@link ILexerAdapter} object provided by an {@link IConfiguration}. Thus it is the
 * {@link IConfiguration}s implementations task to realize the adaptation of the lexer.
 * 
 * @author C. Bürger
 *
 */
public interface ILexerAdapter {
	/**
	 * Method used to change the current input stream, representing the source
	 * code to scan, and reset the lexer to its initial state.
	 * 
	 * @param inputSourceCode The new source code to scan now.
	 * @throws ConfigurationException Is thrown, if the lexer can
	 * not be reseted or the source code to analyze can not be changed or is
	 * malformed.
	 */
	public void initialize(Reader inputSourceCode) throws ConfigurationException;
	
	/**
	 * Retrieves the next token of the source code to analyze. The result may be
	 * the EOF token, representing the end of file, thus the input has been
	 * completely scanned successful. Every further invocation of this method,
	 * after the complete source code has been successful analyzed will return
	 * the EOF token again.
	 * 
	 * @return The next token read, while analyzing the source code.
	 * @throws ConfigurationException Is thrown, if the lexer was
	 * not able to do further lexical analyzes, so it can not conclude which
	 * token is the next or if the input stream is not confirming the
	 * language specification. Such an exception will for example be thrown
	 * if the source stream can not be read.
	 * @throws LexingError Is thrown, if the next lexem in the
	 * source code doesn't fit any token, e.g. if it contains unknown signs.
	 */
	public TestToken nextToken() throws ConfigurationException, LexingError;
	
	/**
	 * Returns the token representing the end-of-file. Thats the token returned,
	 * when all the source code has been successful analyzed.
	 * 
	 * @return The token representing a completed lexcial analyze of all the
	 * source code.
	 * @throws ConfigurationException Is thrown, if the EOF token
	 * can not be retrieved, created or isn't specified at all.
	 */
	public TestToken getEOFToken() throws ConfigurationException;
	
	/**
	 * Class used to represent on the one side test token, encoding the token
	 * informations the lexer to test has to deliver (so TestToken are used to
	 * specify expected lexer token), as well as token results of the lexer.<br>
	 * <br>
	 * The lexer can of course use his own token representations, it's only
	 * necessary for the test suite, that the necessary token informations are
	 * available and published as TestToken instances. If an adaptation is
	 * necessary, it can be done by using an appropriate {@link IConfiguration}
	 * instance to configure the lexical test suite (setting the
	 * {@link Main#config} attribute).
	 * 
	 * @author C. Bürger
	 *
	 */
	public class TestToken {
		/**
		 * Unique token type name expected from lexer or read by the lexer, depending
		 * if the TestToken is used to specify a test, so it's specifying which
		 * token the lexer has to deliver, or the TestToken is used to store a
		 * lexer's scanning result.<br>
		 * <br>
		 * If the TestToken is used to store a lexers result and type == null, the
		 * lexer encountered an unknown lexem, thus failed scanning some source code.
		 */
		public String type;
		/**
		 * The lexem the lexer has to read or actually read for this test token.
		 */
		public String lexem;
		
		/**
		 * Returns a real clone, not sharing any data structure or references.
		 */
		public Object clone() {
			TestToken result = new TestToken();
			result.type = type;
			result.lexem = lexem;
			return result;
		}
	}
	
	/**
	 * This exceptions are thrown if the lexer is invoked to read the next token,
	 * but the next lexem is unknown, thus the source code isn't correct. Exceptions
	 * of this type are special handled by the {@link PositiveTest#runTest()}
	 * and {@link NegativeTest#runTest()} methods.
	 * 
	 * @author C. Bürger
	 *
	 */
	final public static class LexingError extends FailedTestException {
		public static final long serialVersionUID = 1L;
		
		private String unknownLexem;
		private int line;
		private int column;
		
		/**
		 * Constructs an {@link LexingError} representing a failed lexical analysis,
		 * because an unknown lexem occured while scanning.
		 * 
		 * @param line The line in the source code the unknown lexem occured.
		 * @param column The column in the source code the unknown lexem occured.
		 * @param unknownLexem The unknown lexem.
		 */
		public LexingError(int line, int column, String unknownLexem) {
			super("Unknown lexem while scanning : " + unknownLexem);
			
			this.line = line;
			this.column = column;
			this.unknownLexem = unknownLexem;
		}
		
		/**
		 * Returns the line on which the unknown lexem in the source code occured.
		 * 
		 * @return Line the unknown lexem has been encountered.
		 */
		public int getLine() {
			return line;
		}
		
		/**
		 * Returns the column on which the unknown lexem in the source code occured.
		 * 
		 * @return Column the unknown lexem has been encountered.
		 */
		public int getColumn() {
			return column;
		}
		
		/**
		 * Returns the unknown lexem encountered while scanning some source code.
		 * 
		 * @return Unknown lexem encountered.
		 */
		public String getUnknownLexem() {
			return unknownLexem;
		}
	}
}
