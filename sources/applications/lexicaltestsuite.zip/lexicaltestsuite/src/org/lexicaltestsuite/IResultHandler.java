package org.lexicaltestsuite;

import org.lexicaltestsuite.LexicalTestSuite.ErrorsLexicalTestSuite;
import org.lexicaltestsuite.LexicalTestSuite.ErrorsNegativeTestsLexicalTestSuite;
import org.lexicaltestsuite.LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite;
import org.lexicaltestsuite.LexicalTests.ErrorsLexicalTests;
import org.lexicaltestsuite.NegativeTest.ErrorNegativeTest;
import org.lexicaltestsuite.NegativeTest.ErrorsNegativeTest;
import org.lexicaltestsuite.PositiveTest.ErrorPositiveTest;

/**
 * Interface used to handle results returned by lexical tests
 * containing failed tests. Failed tests are represented by
 * {@link FailedTestException}s. Implementations of this
 * interface support methods taking such exceptions and handle them
 * somehow, e.g. printing a logging file.
 * 
 * @author C. Bürger
 *
 */
public interface IResultHandler {

	/**
	 * Uses the informations of the failed tests to do additional
	 * computations. The problem has not to be solved. For example
	 * it may just be written in a test data base. The error object
	 * representing failed lexical tests will be decomposed into
	 * its sub error objects and for each of it the corresponding
	 * handleResult method of this ILexicalTestsResultHandler
	 * will be called.
	 * 
	 * @param error The error object representing failed lexical tests.
	 * @throws ConfigurationException Is thrown, if the
	 * lexical test suite itself is erroneous (e.g. contains program
	 * errors or is wrong configured).
	 */
	public abstract void handleResult(ErrorsLexicalTests error)
			throws ConfigurationException;

	/**
	 * Similar to {@link #handleResult(LexicalTests.ErrorsLexicalTests)},
	 * expect other kind of errors are handled.
	 */
	public abstract void handleResult(ErrorsLexicalTestSuite error)
			throws ConfigurationException;

	/**
	 * Similar to {@link #handleResult(LexicalTests.ErrorsLexicalTests)},
	 * expect other kind of errors are handled.
	 */
	public abstract void handleResult(ErrorsPositiveTestsLexicalTestSuite error)
			throws ConfigurationException;

	/**
	 * Similar to {@link #handleResult(LexicalTests.ErrorsLexicalTests)},
	 * expect other kind of errors are handled.
	 */
	public abstract void handleResult(ErrorsNegativeTestsLexicalTestSuite error)
			throws ConfigurationException;

	/**
	 * Handler for atomic failed positive test cases, thus a
	 * decomposition in further errors contained will not be done.<br>
	 * <br>
	 * Beside its atomic behavior it's semantics are still similar to
	 * {@link #handleResult(LexicalTests.ErrorsLexicalTests)}.
	 */
	public abstract void handleResult(ErrorPositiveTest error)
			throws ConfigurationException;

	/**
	 * Similar to {@link #handleResult(LexicalTests.ErrorsLexicalTests)},
	 * expect other kind of errors are handled.
	 */
	public abstract void handleResult(ErrorsNegativeTest error)
			throws ConfigurationException;

	/**
	 * Handler for atomic failed negative test cases, thus a
	 * decomposition in further errors contained will not be done.<br>
	 * <br>
	 * Beside its atomic behavior it's semantics are still similar to
	 * {@link #handleResult(LexicalTests.ErrorsLexicalTests)}.
	 */
	public abstract void handleResult(ErrorNegativeTest error)
			throws ConfigurationException;
}
