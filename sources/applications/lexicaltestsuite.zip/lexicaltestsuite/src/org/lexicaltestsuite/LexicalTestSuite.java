package org.lexicaltestsuite;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.IOException;

import java.net.MalformedURLException;

import java.util.List;
import java.util.LinkedList;

import org.jdom.*;
import org.jdom.input.SAXBuilder;

import org.lexicaltestsuite.NegativeTest.ErrorsNegativeTest;
import org.lexicaltestsuite.PositiveTest.ErrorPositiveTest;

/**
 * Class representing test files consisting of positive and
 * negative tests. This class allows to read and store
 * the tests of test files, as well as to execute them. A test
 * suite consists of a set of {@link PositiveTest positive} tests and
 * a set of {@link NegativeTest negative} tests<br>
 * <br>
 * If tests are executed and no {@link ErrorsLexicalTestSuite}
 * exception is thrown, all tests of the test suite have been successful.
 * Otherwise some test(s) failed.
 * 
 * @author C. Bürger
 * 
 */
public class LexicalTestSuite {
	/**
	 * The test file represented by this test suite.
	 */
	public File xmlTestFile;
	/**
	 * List of all the positive tests contained in the test file
	 * this test suite object has been constructed from.
	 */
	public List<PositiveTest> positiveTests;
	/**
	 * List of all the negative tests contained in the test file
	 * this test suite object has been constructed from.
	 */
	public List<NegativeTest> negativeTests;
	/**
	 * The description given for the test suite in the test file
	 * this test suite object has been constructed from.
	 */
	public String description;
	
	/**
	 * Constructs an object representing one xml lexical test file, thus one
	 * lexical test suite. To do so, an arbitrary xml test file is read, it's
	 * tests are stored in memory and methods to execute the tests are provided.
	 * 
	 * @param xmlTestFile The xml test file describing a set of lexical tests. It
	 * will be read and form the tests for this test suite.
	 * @throws ConfigurationException Is thrown, if the lexical test
	 * suite contains errors (implementation errors as well as errors in the xml
	 * lexical test file read).
	 */
	public LexicalTestSuite(File xmlTestFile) throws ConfigurationException {
		initialize(xmlTestFile);
	}
	
	/**
	 * Semantics are the same like the ones of the {@link #LexicalTestSuite(File)}
	 * constructor, expect no new test suite is constructed, instead this test suite's
	 * tests will be the ones specified in the xml lexical test file. Allready stored
	 * tests in this LexicalTestSuite will be deleted.
	 */
	public void initialize(File xmlTestFile) throws ConfigurationException {
		if (xmlTestFile == null)
			throw new ConfigurationException("Can't build lexical test suite org.jdom.Document : " +
					"File object representing xml test file needed.");
		
		this.xmlTestFile = xmlTestFile;
		retrieveTestData(buildTestDocument());
	}
	
	private Document buildTestDocument() throws ConfigurationException {
		try {
			SAXBuilder builder = new SAXBuilder(true);
			
			builder.setFeature("http://apache.org/xml/features/validation/schema", true);
			builder.setProperty("http://apache.org/xml/properties/schema" +
					"/external-noNamespaceSchemaLocation",
					LexicalTestSuite.class.getResource("LexicalTestSchema.xsd").toString());
			
			return builder.build(new InputStreamReader(new FileInputStream(xmlTestFile), "UTF-8"));
		} catch (JDOMException exception) {
			throw new ConfigurationException("Error in lexical test case. Cause: " +
					JDOMException.class.getName() + " (Exception) while reading lexical test data from xml test file [" +
					xmlTestFile.getAbsolutePath() + "]. Check xml test file path/name/schema conformance and schema availability.",
					exception);
		} catch (MalformedURLException exception) {
			throw new ConfigurationException(MalformedURLException.class.getName() +
					" (Exception) while trying to get lexical xml test file schema.", exception);
		} catch (IOException exception) {
			throw new ConfigurationException(IOException.class.getName() +
					" (Exception) while reading lexical test data from xml test file [" +
					xmlTestFile.getAbsolutePath() + "] or while trying to get lexical xml test file schema. " +
					"Check xml test file path/name.", exception);
		}
	}
	
	private void retrieveTestData (Document doc) {
		description = doc.getRootElement().getAttributeValue("Description");
		positiveTests = new LinkedList<PositiveTest>();
		negativeTests = new LinkedList<NegativeTest>();
		
		for (Element testFragment:(List<Element>)doc.getRootElement().getChild("PositiveTests").getChildren()) {
			PositiveTest positiveTest = new PositiveTest();
			positiveTest.description = testFragment.getAttributeValue("Description");
			positiveTest.sourceCode = testFragment.getChildText("SourceCode");
			positiveTest.tokenToRecognize = new LinkedList<ILexerAdapter.TestToken>();
			for (Element token:(List<Element>)testFragment.getChild("ExpectedToken").getChildren("Token")) {
				ILexerAdapter.TestToken testToken = new ILexerAdapter.TestToken();
				testToken.type = token.getAttributeValue("Type");
				testToken.lexem = token.getChildText("Lexem");
				positiveTest.tokenToRecognize.add(testToken);
			}
			positiveTests.add(positiveTest);
		}
		
		for (Element testFragment:(List<Element>)doc.getRootElement().getChild("NegativeTests").getChildren()) {
			NegativeTest negativeTest = new NegativeTest();
			negativeTest.description = testFragment.getAttributeValue("Description");
			negativeTest.faultySourceCodes = new LinkedList<String>();
			for (Element sourceCode:(List<Element>)testFragment.getChildren()) {
				negativeTest.faultySourceCodes.add(sourceCode.getText());
			}
			negativeTests.add(negativeTest);
		}
	}
	
	/**
	 * Executes all {@link #runPositiveTests() positive} and {@link #runNegativeTests()
	 * negative} tests of this test suite. If a test fails, an {@link ErrorsLexicalTestSuite}
	 * exception is thrown <b>after</b> all tests have been executed.
	 * 
	 * @throws ConfigurationException Is thrown if the test suite contains
	 * errors.
	 * @throws ErrorsLexicalTestSuite Is thrown if a test failed.
	 */
	public void runTests() throws ConfigurationException, ErrorsLexicalTestSuite {
		ErrorsLexicalTestSuite errors = null;
		
		try {
			runPositiveTests();
		} catch (ErrorsLexicalTestSuite error) {
			errors = error;
		}
		
		try {
			runNegativeTests();
		} catch (ErrorsLexicalTestSuite error) {
			if (errors != null)
				errors.errorsNegativeTests = error.errorsNegativeTests;
			else errors = error; 
		}
		
		if (errors != null)
			throw errors;
	}
	
	/**
	 * Executes all {@link PositiveTest}s of this test suite. If a test
	 * fails, an {@link ErrorsLexicalTestSuite} exception is thrown <b>after</b>
	 * all tests have been executed.
	 * 
	 * @throws ConfigurationException Is thrown if the test suite
	 * contains errors.
	 * @throws ErrorsLexicalTestSuite Is thrown if a test failed.
	 */
	public void runPositiveTests() throws ConfigurationException, ErrorsLexicalTestSuite {
		ErrorsLexicalTestSuite errorsSuite = new ErrorsLexicalTestSuite();
		errorsSuite.xmlTestFile = xmlTestFile;
		errorsSuite.description = description;
		ErrorsPositiveTestsLexicalTestSuite errors = new ErrorsPositiveTestsLexicalTestSuite();
		errorsSuite.errorsPositiveTests = errors;
		
		int testNumber = 1;
		for (PositiveTest positiveTest:positiveTests) {
			try {
				positiveTest.runTest();
			} catch (ErrorPositiveTest error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errorsSuite;
	}
	
	/**
	 * Executes all {@link NegativeTest}s of this test suite. If a test
	 * fails, an {@link ErrorsLexicalTestSuite} exception is thrown <b>after</b>
	 * all tests have been executed.
	 * 
	 * @throws ConfigurationException Is thrown if the test suite
	 * contains errors.
	 * @throws ErrorsLexicalTestSuite Is thrown if a test failed.
	 */
	public void runNegativeTests() throws ConfigurationException, ErrorsLexicalTestSuite {
		ErrorsLexicalTestSuite errorsSuite = new ErrorsLexicalTestSuite();
		errorsSuite.xmlTestFile = xmlTestFile;
		errorsSuite.description = description;
		ErrorsNegativeTestsLexicalTestSuite errors = new ErrorsNegativeTestsLexicalTestSuite();
		errorsSuite.errorsNegativeTests = errors;
		
		int testNumber = 1;
		for (NegativeTest negativeTest:negativeTests) {
			try {	
				negativeTest.runTest();
			} catch (ErrorsNegativeTest error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errorsSuite;
	}
	
	/**
	 * Exceptions thrown, if a test contained in a {@link LexicalTestSuite}
	 * failed, while executing a test method of the {@link LexicalTestSuite}
	 * class. As tests in a lexical test suite are distinguished in {@link
	 * PositiveTest positive} and {@link NegativeTest negative}
	 * tests, this class wrapps an {@link ErrorsPositiveTestsLexicalTestSuite}
	 * and an {@link ErrorsNegativeTestsLexicalTestSuite} exception.<br>
	 * <br>
	 * Instances of this class are always associated with :<br>
	 *  - a {@link LexicalTestSuite} object of which<br>
	 *  - one of it's tests methods has been executed and<br>
	 *  - some of it's tests failed while execution and<br>
	 *  - the failed tests are represented by this ErrorsLexicalTestSuite
	 *    exception.<br>
	 * <br>
	 * ErrorsLexicalTestSuite exceptions are only thrown by test methods of
	 * {@link LexicalTestSuite}s if some tests during their execution failed,
	 * and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsLexicalTestSuite extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private File xmlTestFile;
		private String description;
		private ErrorsPositiveTestsLexicalTestSuite errorsPositiveTests;
		private ErrorsNegativeTestsLexicalTestSuite errorsNegativeTests;
		
		private ErrorsLexicalTestSuite() {
			errorsPositiveTests = null;
		}
		
		public String getMessage() {
			final String lineSep = System.getProperty("line.separator");
			StringBuilder result = new StringBuilder(512);
			
			result.append("Failed lexical tests in file ");
			result.append(xmlTestFile.getAbsolutePath());
			result.append(" : ");
			if (errorsPositiveTests != null) {
				result.append(lineSep);
				result.append(errorsPositiveTests.getMessage());
			}
			if (errorsNegativeTests != null) {
				result.append(lineSep);
				result.append(errorsNegativeTests.getMessage());
			}
			result.append(lineSep);
			result.append("Test file description : ");
			result.append(description);
			
			return result.toString();
		}
		
		/**
		 * Returns the xml test file associated with the {@link LexicalTestSuite}
		 * this ErrorsLexicalTestSuite exception has been thrown for, because one
		 * of the lexical test suites tests failed while executing a lexical test
		 * suites test method.
		 * 
		 * @return XML test file associated with the test suite containing
		 * failed tests reported by this ErrorsLexicalTestSuite exception.
		 */
		public File getTestFile() {
			return xmlTestFile;
		}
		
		/**
		 * Returns the description of the lexical test suite, as it has been given
		 * in the xml test file represented by the lexical test suite.
		 * 
		 * @return Description of the lexical test suite.
		 */
		public String getTestFileDescription() {
			return description;
		}
		
		/**
		 * Returns the {@link ErrorsPositiveTestsLexicalTestSuite} represented
		 * by this ErrorsLexicalTestSuite or null if this ErrorsLexicalTestSuite
		 * object doesn't represent failed positive tests. E.g. this might be the
		 * case, if only negative tests have been executed and some of it failed,
		 * which still results in an ErrorsLexicalTestSuite exception.
		 * 
		 * @return Positive failed tests exception or null, if no positive test
		 * failed while executing test methods of a {@link LexicalTestSuite}s
		 * test method.
		 */
		public ErrorsPositiveTestsLexicalTestSuite hasErrorsPositiveTests() {
			return errorsPositiveTests;
		}
		
		/**
		 * Returns the {@link ErrorsNegativeTestsLexicalTestSuite} represented
		 * by this ErrorsLexicalTestSuite or null if this ErrorsLexicalTestSuite
		 * object doesn't represent failed negative tests. E.g. this might be the
		 * case, if only positive tests have been executed and some of it failed,
		 * which still results in an ErrorsLexicalTestSuite exception.
		 * 
		 * @return Negative failed tests exception or null, if no negative test
		 * failed while executing test methods of a {@link LexicalTestSuite}s
		 * test method.
		 */
		public ErrorsNegativeTestsLexicalTestSuite hasErrorsNegativeTests() {
			return errorsNegativeTests;
		}
	}
	
	/**
	 * Exceptions thrown, if some {@link PositiveTest positive} test(s)
	 * contained in a {@link LexicalTestSuite} failed, while executing a test
	 * method of the {@link LexicalTestSuite} class.<br>
	 * <br>
	 * As a lexical test suite may contain an arbitrary number of positive
	 * lexical tests, it is necessary to know, which positive tests actually
	 * failed while executing a test method of the test suite. To do so,
	 * the ErrorsPositiveTestsLexicalTestSuite exception contains, additionally
	 * to a list of all the {@link PositiveTest.ErrorPositiveTest positive
	 * test exceptions} of the positive tests failed, also their numbers in the list
	 * of positive lexical tests of the lexical test suite for which this
	 * ErrorsPositiveTestsLexicalTestSuite has been thrown.
	 * <br>
	 * ErrorsPositiveTestsLexicalTestSuite exceptions are only thrown by test
	 * methods of {@link LexicalTestSuite}s if some <b>positive</b> test(s)
	 * during their execution failed, and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsPositiveTestsLexicalTestSuite extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private List<Integer> testNumbers;
		private List<ErrorPositiveTest> testErrors;
		
		private ErrorsPositiveTestsLexicalTestSuite() {
			testNumbers = new LinkedList<Integer>();
			testErrors = new LinkedList<ErrorPositiveTest>();
		}
		
		public String getMessage() {
			return testNumbers.size() + " positive test(s) from " +
				LexicalTestSuite.class.getName() + " instance failed.";
		}
		
		/**
		 * Returns the number of failed positive tests while executing a test
		 * method of a {@link LexicalTestSuite}.
		 * 
		 * @return Number of failed positive tests, while executing a test method
		 * of the {@link LexicalTestSuite} this ErrorsPositiveTestsLexicalTestSuite
		 * is associated with.
		 */
		public int getNumberOfFailedTests() {
			return testNumbers.size();
		}
		
		/**
		 * Returns the list position in the list of negative tests of the
		 * {@link LexicalTestSuite} this ErrorsPositiveTestsLexicalTestSuite
		 * exception is associated with, because it has been thrown as exception
		 * while executing one of the {@link LexicalTestSuite}s test methods.
		 *  
		 * @param nthFailedTest The position in the list of {@link ErrorPositiveTest
		 * positive tests} of this ErrorsPositiveTestsLexicalTestSuite.
		 * @return The position in the list of {@link PositiveTest}s of
		 * the {@link LexicalTestSuite} this ErrorsPositiveTestsLexicalTestSuite is
		 * associated with.
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Returns the n'th {@link ErrorPositiveTest positive test exception} in the
		 * list of positive test exceptions of this ErrorsPositiveTestsLexicalTestSuite.
		 * 
		 * @param nthFailedTest Position in the list of {@link ErrorPositiveTest} of
		 * this ErrorsPositiveTestsLexicalTestSuite.
		 * @return The {@link ErrorPositiveTest} exception at the given position.
		 */
		public ErrorPositiveTest getTestError(int nthFailedTest) {
			return testErrors.get(nthFailedTest);
		}
	}
	
	/**
	 * The semantics of this exception are analog to the ones of the
	 * {@link LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite} class,
	 * expect, instead of positive failed lexical tests, negative ones are treated.<br>
	 * <br>
	 * So associated classes are :<br>
	 *  - {@link LexicalTestSuite}<br>
	 *  - {@link NegativeTest}<br>
	 *  - {@link NegativeTest.ErrorsNegativeTest}<br>
	 *  <br>
	 *  Another exception class for all failed negative tests in lexical test suites
	 *  has been developed, to retrieve type save test results and to address further
	 *  lexical test suite extensions.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsNegativeTestsLexicalTestSuite extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private List<Integer> testNumbers;
		private List<ErrorsNegativeTest> testErrors;
		
		private ErrorsNegativeTestsLexicalTestSuite() {
			testNumbers = new LinkedList<Integer>();
			testErrors = new LinkedList<ErrorsNegativeTest>();
		}
		
		public String getMessage() {
			return testNumbers.size() + " negative test(s) from " +
				LexicalTestSuite.class.getName() + " instance failed.";
		}
		
		/**
		 * Analog to
		 * {@link LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite#getNumberOfFailedTests()}
		 * method.
		 * 
		 */
		public int getNumberOfFailedTests() {
			return testNumbers.size();
		}
		
		/**
		 * Analog to
		 * {@link LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite#getTestNumber(int)}
		 * method.
		 * 
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Analog to
		 * {@link LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite#getTestError(int)}
		 * method.
		 * 
		 */
		public ErrorsNegativeTest getTestError(int nthFailedTest) {
			return testErrors.get(nthFailedTest);
		}
	}
}
