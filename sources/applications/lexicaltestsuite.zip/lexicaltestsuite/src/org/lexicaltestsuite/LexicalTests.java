package org.lexicaltestsuite;

import java.io.File;

import java.util.List;
import java.util.LinkedList;

import org.lexicaltestsuite.LexicalTestSuite.ErrorsLexicalTestSuite;

/**
 * Class used to store an arbitrary number of {@link LexicalTestSuite}s.<br>
 * <br>
 * Lexical tests are specified as <b>lexical test suites</b>. Each
 * lexical test suite is specified as xml file and has to confirm the
 * lexical test suite xml file schema. For every such file a
 * {@link LexicalTestSuite} instance can be constructed, representing the test
 * file. Thus, the LexicalTests class constructs, stores and executes such
 * {@link LexicalTestSuite}s, it is a {@link LexicalTestSuite}s collection.<br>
 * <br>
 * The <b>initialization/construction</b> means :<br>
 *  - To specify a collection of files representing lexical tests and to<br>
 *    construct for each file a {@link LexicalTestSuite} object representing<br>
 *    the lexical test. All the {@link LexicalTestSuite} objects will be<br>
 *    collected in this {@link LexicalTests} object.<br>
 * <br>
 * Lexical tests/test suites consist of positive and negative tests. A
 * <b>positive test</b> checks if something is successful scanned and it
 * verifies, that the results of the scanner confirm the expected ones.
 * It only is successful, if the scanning was possible and the results are
 * confirming the expected ones. A <b>negative test</b> checks, if something can not
 * be scanned and the test is only successful if this is the case.<br>
 * <br>
 * To <b>execute</b> lexical tests three methods can be used :<br>
 *  - The {@link #runTests()} method executing all tests.<br>
 *  - The {@link #runPositiveTests()} method executing all positive tests.<br>
 *  - The {@link #runNegativeTests()} method executing all negative tests.<br>
 * Weather all tests or only a few are executed, always the complete lexical tests
 * are initialized and stored as data structure in memory. So (different) tests can
 * be executed several times.<br>
 * <br>
 * If any test suite fails, thus one of its tests failed, an
 * {@link ErrorsLexicalTests} exception will be thrown. It contains
 * {@link ErrorsLexicalTestSuite} exceptions for every test suite with failed
 * tests. This test suite exceptions them self contain exceptions for the failed
 * positive tests ({@link PositiveTest.ErrorPositiveTest})
 * and exceptions for the failed negative tests
 * ({@link NegativeTest.ErrorNegativeTest}). So the tests
 * results form a composition on pair with the lexical test files structure.<br>
 * <br>
 * Results of lexical test execution can be evaluated by a
 * {@link IResultHandler}. If the failed tests shall be handled,
 * an {@link IResultHandler} instance doing this can
 * be retrieved invoking the {@link IConfiguration#createResultHandler()}
 * method of the configuration used for the lexical test suite. The
 * {@link AConfiguration} class uses a {@link ResultPrinter} to handle failed
 * lexical tests and print a log file.
 * <br>
 * {@link ConfigurationException}s are thrown, if lexical test files
 * contain errors or something else is broken in the lexical test suite. Examples
 * for errors in the test suite itself are :<br>
 *  - Test files not confirming the xml test file schema.<br>
 *  - Token specified in test files unknown by the scanner.<br>
 *  - The test file xml schema can not be loaded.<br>
 *  - Tests files can not be read or other IOExceptions in general.<br>
 * and so one.<br>
 * <br>
 * Configuration for the lexical test suite are represented by
 * {@link IConfiguration} implementations. There things like :<br>
 *  - the lexer to use<br>
 *  - the {@link IResultHandler} instance handling failed test results<br>
 * are/can be specified. The lexical test suite uses the {@link Main#config}
 * attribute to store the {@link IConfiguration configuration} to use. The
 * attribute must be initialized to use the lexical test suite.
 * 
 * @author C. Bürger
 *
 */
public class LexicalTests {
	/**
	 * List of all the {@link LexicalTestSuite}s contained in this LexicalTests
	 * object.
	 */
	public List<LexicalTestSuite> tests;
	
	/**
	 * Initializes, stores and returns an object representing a collection of
	 * lexical test suites.
	 * 
	 * @param testFiles The *.xml files representing test cases to execute.
	 * @throws ConfigurationException Thrown, if the lexical tests
	 * them self are erroneous.
	 */
	public LexicalTests (List<File> testFiles) throws ConfigurationException {
		initialize(testFiles);
	}
	
	/**
	 * Initializes and stores this collection of lexical test suites. The
	 * collection is emptied before, thus the semantics are the same as for
	 * the {@link #LexicalTests(List) constructor}.
	 */
	public void initialize (List<File> testFiles) throws ConfigurationException {
		if (testFiles == null || testFiles.size() < 1)
			throw new ConfigurationException(
					"No *.xml test files to execute specified.");
		tests = new LinkedList<LexicalTestSuite>();
		for (File test:testFiles) {
			tests.add(new LexicalTestSuite(test));
		}
	}
	
	/**
	 * Executes all tests of all the lexical test suites contained in this
	 * {@link LexicalTestSuite}s collection. The semantics are the same like
	 * executing all {@link #runPositiveTests() positive} and
	 * {@link #runNegativeTests() negative} lexical tests of the test suites
	 * contained.
	 * 
	 * @throws ConfigurationException Thrown, if the lexical
	 * tests them self are erroneous.
	 * @throws ErrorsLexicalTests Thrown, if any test of the
	 * {@link LexicalTestSuite}s contained failed. All tests are still
	 * executed, thus the failed lexical test exception is thrown after
	 * execution.
	 */
	public void runTests() throws ConfigurationException, ErrorsLexicalTests {
		ErrorsLexicalTests errors = new ErrorsLexicalTests();
		
		int testNumber = 1;
		for (LexicalTestSuite testSuite:tests) {
			try {
				testSuite.runTests();
			} catch (ErrorsLexicalTestSuite error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errors;
	}
	
	/**
	 * Executes all positive tests of all the lexical test suites contained
	 * in this {@link LexicalTestSuite LexicalTestSuites} collection. Thus,
	 * the {@link LexicalTestSuite#runPositiveTests()} method for each test
	 * suite is executed.
	 * 
	 * @throws ConfigurationException Thrown, if the lexical tests
	 * them self are erroneous.
	 * @throws ErrorsLexicalTests Thrown, if any positive test of the
	 * {@link LexicalTestSuite LexicalTestSuites} contained failed. All tests
	 * are still executed, thus the failed lexical test exception is thrown after
	 * execution.
	 */
	public void runPositiveTests() throws ConfigurationException, ErrorsLexicalTests {
		ErrorsLexicalTests errors = new ErrorsLexicalTests();
		
		int testNumber = 1;
		for (LexicalTestSuite testSuite:tests) {
			try {
				testSuite.runPositiveTests();
			} catch (ErrorsLexicalTestSuite error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errors;
	}
	
	/**
	 * Semantics are the same as for the {@link #runPositiveTests()}
	 * method, expect only negative tests are executed.
	 */
	public void runNegativeTests() throws ConfigurationException, ErrorsLexicalTests {
		ErrorsLexicalTests errors = new ErrorsLexicalTests();
		
		int testNumber = 1;
		for (LexicalTestSuite testSuite:tests) {
			try {
				testSuite.runNegativeTests();
			} catch (ErrorsLexicalTestSuite error) {
				errors.testNumbers.add(testNumber);
				errors.testErrors.add(error);
			}
			testNumber++;
		}
		
		if (errors.getNumberOfFailedTests() > 0)
			throw errors;
	}
	
	/**
	 * The class implements exception thrown, if any test failed, while performing
	 * tests of a {@link LexicalTests} instance. So instances of this class are
	 * thrown by the test methods of the {@link LexicalTests} class.<br>
	 * <br>
	 * An ErrorsLexicalTests exception contains all {@link ErrorsLexicalTestSuite}
	 * exceptions thrown by {@link LexicalTestSuite}s, because any of their tests
	 * has been invoked and failed during performing tests of a {@link LexicalTests}
	 * instance. Additionally it associates a number with every failed
	 * {@link LexicalTestSuite}, telling which test suite it is in the
	 * {@link LexicalTests} instance's test suite collection.
	 * <br>
	 * ErrorsLexicalTests exceptions are only thrown by test methods of
	 * {@link LexicalTests} objects if some tests during their execution failed,
	 * and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsLexicalTests extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private List<Integer> testNumbers;
		private List<ErrorsLexicalTestSuite> testErrors;
		
		private ErrorsLexicalTests() {
			testNumbers = new LinkedList<Integer>();
			testErrors = new LinkedList<ErrorsLexicalTestSuite>();
		}
		
		public String getMessage() {
			return testErrors.size() + "test(s) from " +
				LexicalTests.class.getName() + " instance failed.";
		}
		
		/**
		 * Returns how many {@link LexicalTestSuite}s failed while performing
		 * tests of a {@link LexicalTests} instance.
		 * 
		 * @return Number of {@link LexicalTestSuite}s failed.
		 */
		public int getNumberOfFailedTests() {
			return testNumbers.size();
		}
		
		/**
		 * Keep in mind that ErrorsLexicalTests objects are thrown if
		 * tests of a {@link LexicalTests} instance are executed and fail:
		 * Returns the list position in the list of {@link LexicalTestSuite}
		 * objects, of an {@link LexicalTests} object, for the n'th failed
		 * {@link LexicalTestSuite} of this ErrorsLexicalTests object.
		 * <br>
		 * Thus the result tells, which lexical test suite of an 
		 * {@link LexicalTests} instance failed, while executing a test of it.
		 * 
		 * @param nthFailedTest Position in the list of {@link ErrorsLexicalTestSuite}s
		 * of this ErrorsLexicalTests instance.
		 * @return Position in the list of {@link LexicalTestSuite}s of the
		 * {@link LexicalTests} object executing one of its test methods, which failed
		 * and has thrown this ErrorsLexicalTests object.
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Returns the n'th failed {@link LexicalTestSuite}'s exception contained
		 * in this ErrorsLexicalTests object.
		 * 
		 * @param nthFailedTest Position in the list of {@link ErrorsLexicalTestSuite}s
		 * of this ErrorsLexicalTests instance.
		 * @return Exception thrown, while executing any of the test methods of
		 * a {@link LexicalTestSuite}.
		 */
		public ErrorsLexicalTestSuite getTestError(int nthFailedTest) {
			return testErrors.get(nthFailedTest);
		}
	}
}
