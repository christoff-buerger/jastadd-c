package org.lexicaltestsuite;

import java.util.logging.Formatter;
import java.util.logging.LogRecord;

/**
 * Special logging formatter to pretty print the test suites
 * logging. It just prints the raw messages sent to the logger, each
 * message on a new line.
 * 
 * @author C. Bürger
 *
 */
public class LoggingFormatter extends Formatter {
	public String format(LogRecord record) {
		String message = record.getMessage();
		if (message == null)
			return System.getProperty("line.separator");
		return message + System.getProperty("line.separator");
	}
}
