package org.lexicaltestsuite;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

import java.util.LinkedList;
import java.util.List;

import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.Handler;

import org.lexicaltestsuite.LexicalTests.ErrorsLexicalTests;

/**
 * Class used to execute the lexical test suite from command line
 * {@link #main(String[])} or by the {@link #execute(Class, List, File)} method.
 * The methods will check the given parameters and throw errors if the parameters
 * are not valid.
 * 
 * @author C. Bürger
 *
 */
public class Main {
	/**
	 * The lexical test suite {@link IConfiguration} instance, configuring
	 * the lexical test suite with the {@link ILexerAdapter} and {@link IResultHandler}
	 * to use.
	 */
	public static IConfiguration config;
	
	/**
	 * Logger used to log performed lexical tests as well
	 * as errors encountered.
	 */
	public static Logger logger = initLogger();
	private static Logger initLogger() {
		try {
			Logger logger = Logger.getLogger(LexicalTests.class.getPackage().getName());
			
			// TODO: Is this a hack (surely it is).
			//       Any better solution for the "double console print error" with ant build scripts?
			Logger parent = logger.getParent();
			while (parent != null) {
				Handler[] handlers = parent.getHandlers();
				for (int i = 0; i < handlers.length; i++) {
					logger.log(Level.ALL,
							"Handler ["+ handlers[i].getClass().getName() +";"+
							handlers[i].getLevel().getLocalizedName() +
							"] for parent logger ["+ parent.getName() +
							"] removed (check "+ Main.class.getName() +" implementation)!");
					parent.removeHandler(handlers[i]);
				}
				parent = parent.getParent();
			}
			ConsoleHandler handler = new ConsoleHandler();
			handler.setEncoding("UTF-8");
			handler.setFormatter(new LoggingFormatter());
			handler.setLevel(Level.INFO);
			logger.addHandler(handler);
			
			return logger;
		} catch (Exception exc) {
			throw new RuntimeException(
					"Error while initializing the logger. Cause: "+ exc.getMessage(), exc);
		}
	}
	
	private static void printInputStreamOnStandardOut(InputStream input) throws IOException {
		StringBuilder stringbuf = new StringBuilder();
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				input,
				"UTF-8"));
	
		char[] cbuf = new char[65536];

		int read = 0;
		while (true) {
			read = reader.read(cbuf, 0, 65536);
			if(read < 0)
				break;
			stringbuf.append(cbuf, 0, read);
		}
		
		System.out.append(stringbuf);
	}
	
	/**
	 * Starts the initialization and execution of lexical tests from the command line.
	 * For details about command line usage check the 'usage.txt' file.
	 * 
	 * @throws ConfigurationException Thrown, if the lexical tests
	 * them self are erroneous.
	 */
	public static void main(String[] args) throws ConfigurationException {
		// If no arguments are given print a help message:
		if (args.length < 1) {
			final String corruptedError = "FATAL: Can't open help file usage.txt.";
			
			InputStream usageInput =
				LexicalTests.class.getResourceAsStream("usage.txt");
			
			if (usageInput == null)
				throw new RuntimeException(corruptedError);
			
			try {
				printInputStreamOnStandardOut(usageInput);
			} catch (IOException exc) {
				throw new ConfigurationException(corruptedError, exc);
			}
			return;
		}
		
		List<File> tests = null;
		String configurationClassName = null;
		File configurationLocation = null;
		Class<?> configurationClass = null;
		File loggingFile = null;
		
		for (int i = 0; i < args.length; i++) {
			if (args[i].equals("-license")) {
				InputStream licenseInput =
					LexicalTests.class.getResourceAsStream("License.txt");
				
				final String corruptedError =
					"FATAL: Can't open license file License.txt.\nCorrupted Lexical-Test-Suite version!";
				
				if (licenseInput == null)
					throw new RuntimeException(corruptedError);
				
				try {	
					printInputStreamOnStandardOut(licenseInput);
				} catch (IOException exception) {
					throw new RuntimeException(corruptedError);
				}
				continue;
			} else if (args[i].equals("-c")) {
				if (configurationClassName != null)
					throw new ConfigurationException(
							"Configuration to use several times specified.");
				i++;
				if (args.length < i || args[i].equals("-license") || args[i].equals("-c") ||
						args[i].equals("-s") || args[i].equals("-log"))
					throw new ConfigurationException(
							"No class file location for configuration parameter specified");
				configurationLocation = new File(args[i]);
				i++;
				if (args.length < i || args[i].equals("-license") || args[i].equals("-c") ||
						args[i].equals("-s") || args[i].equals("-log"))
					throw new ConfigurationException(
							"No class name for configuration parameter specified");
				configurationClassName = args[i];
				continue;
			} else if (args[i].equals("-s")) {
				if (tests != null)
					throw new ConfigurationException(
							"Tests to execute parameter (-s) several times specified.");
				tests = new LinkedList<File>();
				i++;
				int numberOfTests = 0;
				while (i < args.length) {
					if (args[i].equals("-license") || args[i].equals("-c") ||
							args[i].equals("-s") || args[i].equals("-log")) {
						i--;
						break;
					}
					tests.add(new File(args[i]));
					numberOfTests++;
					i++;
				}
				if (numberOfTests == 0)
					throw new ConfigurationException(
							"No test files for -s parameter specified.");
				continue;
			} else if (args[i].equals("-log")) {
				if (loggingFile != null)
					throw new ConfigurationException(
							"File to write the log to is several times specified.");
				i++;
				if (args.length < i || args[i].equals("-c") || args[i].equals("-license") ||
						args[i].equals("-s") || args[i].equals("-log"))
					throw new ConfigurationException(
							"No file for logging parameter (-log) specified.");
				loggingFile = new File(args[i]);
				continue;
			} else throw new ConfigurationException(
					"Unknown command line parameter ["+ args[i] +"].");
		}
		
		// Load the specified configuration:
		if (configurationLocation != null) {
			URL[] compilerClassLocationURL = new URL[1];
			try {
				compilerClassLocationURL[0] = configurationLocation.toURI().toURL();
			} catch (MalformedURLException exception) {
				throw new IllegalArgumentException(exception);
			}
			
			URLClassLoader classLoader = new URLClassLoader(compilerClassLocationURL);
			try {
				configurationClass = classLoader.loadClass(configurationClassName);
			} catch (ClassNotFoundException exc) {
				throw new IllegalArgumentException(
						"The configuration specified cannot be found. Cause: "+ exc.getMessage(), exc);
			}
		}
		
		execute(configurationClass, tests, loggingFile);
	}
	
	/**
	 * Starts the initialization and execution of lexical tests.
	 * 
	 * @param configurationClass The {@link IConfiguration} class to use.
	 * @param tests The *.xml test cases to execute.
	 * @throws ConfigurationException Thrown, if the lexical tests
	 * them self are erroneous.
	 */
	public static void execute(Class<?> configurationClass,
			List<File> tests, File loggingFile) throws ConfigurationException {
		if (configurationClass == null)
			throw new ConfigurationException(
					"No configuration for the lexical test suite specified.");
		Object configuration = null;
		try {
			configuration = configurationClass.newInstance();
		} catch (InstantiationException exc) {
			throw new ConfigurationException(
					"The configuration class ["+
					configurationClass.getName() +
					"] specified cannot be instanciated. Cause: "+
					exc.getMessage(), exc);
		} catch (IllegalAccessException exc) {
			throw new ConfigurationException(
					"The configuration class ["+
					configurationClass.getName() +
					"] specified cannot be instanciated. Cause: "+
					exc.getMessage(), exc);
		}
		if (!(configuration instanceof IConfiguration))
			throw new ConfigurationException(
					"The configuration class ["+
					configurationClass.getName() +
					"] specified is no ["+
					IConfiguration.class.getName() +
					"] implementation.");
		
		if (tests == null || tests.size() < 1)
			throw new ConfigurationException(
					"No *.xml test files to execute specified.");
		
		for (File test:tests) {
			if (!test.exists())
				throw new ConfigurationException(
						"The test file ["+
						test.getAbsolutePath() +
						"] does not exist.");
			if (!test.isFile())
				throw new ConfigurationException(
						"The test location ["+
						test.getAbsolutePath() +
						"] is no file.");
		}
		
		// Initialize the logger:
		try {
			if (loggingFile != null) {
				if (loggingFile.getParentFile() == null || !loggingFile.getParentFile().exists())
					throw new ConfigurationException(
							"The specified logging file's directory ["+
							loggingFile.getAbsolutePath() +
							"] does not exist.");
				FileHandler fileHandler = new FileHandler(
						loggingFile.getAbsolutePath(),
						0,
						1,
						false);
				fileHandler.setEncoding("UTF-8");
				fileHandler.setFormatter(new LoggingFormatter());
				fileHandler.setLevel(Level.INFO);
				logger.addHandler(fileHandler);
			}
		} catch (Exception exc) {
			throw new ConfigurationException(
					"Error while initializing the logger. Cause: "+ exc.getMessage(), exc);
		}
		
		config = (IConfiguration)configuration;
		
		try {
			LexicalTests lTests = new LexicalTests(tests);
			lTests.runTests();
		} catch (ErrorsLexicalTests error) {
			IResultHandler printer =
				config.createResultHandler();
			
			printer.handleResult(error);
		}
	}
}
