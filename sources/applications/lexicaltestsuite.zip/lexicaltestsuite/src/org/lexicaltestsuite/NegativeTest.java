package org.lexicaltestsuite;

import java.io.StringReader;

import java.util.List;
import java.util.LinkedList;

import org.lexicaltestsuite.ILexerAdapter.LexingError;
import org.lexicaltestsuite.PositiveTest.ErrorPositiveTest;

/**
 * Atomic negative lexical test. A negative lexical test consist of :<br>
 *  - A test description.<br>
 *  - An arbitrary number of source codes, each one not completely
 *    successful scan able.<br>
 * <br>
 * The negative lexical test represented by a NegativeLexicalTest object can
 * be executed invoking it's {@link #runTest()} method. If the test failed, an
 * {@link NegativeTest.ErrorsNegativeTest} exception will be thrown,
 * containing an {@link NegativeTest.ErrorNegativeTest} exception for
 * each source code which has been completely successful scanned.
 * 
 * @author C. Bürger
 *
 */
public class NegativeTest {
	/**
	 * Description for the negative lexical test.
	 */
	public String description;
	/**
	 * List of source codes the scanner to test has to analyze.
	 * Each source code should cause the lexical analyze to fail.
	 */
	public List<String> faultySourceCodes;
	
	/**
	 * Executes the lexical test, testing the lexer provided by the
	 * {@link IConfiguration#getLexerAdapter()} method of the
	 * {@link IConfiguration} implementation used
	 * to configure the lexical test suite.
	 * If no exception is thrown, the test has been successful, thus
	 * all the given source codes caused the lexer to conclude, that
	 * they are not confirming it's accepted language.
	 * 
	 * @throws ConfigurationException Is thrown, if the test
	 * contains errors and it was not possible to do the test at all.
	 * @throws ErrorPositiveTest Is thrown, if the test failed, thus the
	 * lexer is not working as specified by the test.
	 */
	public void runTest() throws ConfigurationException, ErrorsNegativeTest {
		ErrorsNegativeTest errors = new ErrorsNegativeTest();
		errors.testDescription = description;
		
		int negativeTestNumber = 1;
		ILexerAdapter.TestToken EOF = Main.config.getLexerAdapter().getEOFToken();
		for (String testCode:faultySourceCodes) {
			ILexerAdapter lexer = Main.config.getLexerAdapter();
			lexer.initialize(new StringReader(testCode));
		
			List<ILexerAdapter.TestToken> tokenRead = new LinkedList<ILexerAdapter.TestToken>();
			ILexerAdapter.TestToken returnedToken = null;
			do {
				try{
					returnedToken = lexer.nextToken();
				} catch (LexingError exception) {
					return; //We expected an error. It's fine.
				}
				tokenRead.add(returnedToken);
			} while (!returnedToken.type.equals(EOF.type));
			/*
			 * We are still here, thus the source code has been accepted by the lexer ->
			 * The lexer does not function as expected -> Error.
			 */
			errors.testNumbers.add(negativeTestNumber);
			errors.errors.add(new ErrorNegativeTest(
					"Lexical negative test " + negativeTestNumber + " has been successful scanned and didn't fail as expected.",
					testCode,
					tokenRead));
			
			negativeTestNumber++;
		}
		
		if (errors.errors.size() > 0)
			throw errors;
	}
	
	/**
	 * Class implementing exception thrown, if a single negative test failed,
	 * while performing it's {@link PositiveTest#runTest() test method}.<br>
	 * <br>
	 * An ErrorsNegativeTest exception contains :<br>
	 *  - A test description.<br>
	 *  - A list of the source codes which have been completely successful scanned.<br>
	 *  - A list containing the positions of the source codes failed in the associated
	 *    {@link NegativeTest}, which's test method has thrown this
	 *    exception.<br>
	 *  - A list of the {@link NegativeTest.ErrorNegativeTest} exceptions for
	 *    each source code completely scanned successful.<br>
	 * <br>
	 * ErrorsNegativeTest exceptions are only thrown by test methods of
	 * {@link NegativeTest} objects if a test failed,
	 * and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorsNegativeTest extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private String testDescription;
		private List<Integer> testNumbers;
		private List<ErrorNegativeTest> errors;
		
		private ErrorsNegativeTest() {
			testNumbers = new LinkedList<Integer>();
			errors = new LinkedList<ErrorNegativeTest>();
		}
		
		/**
		 * Returns the description of the {@link NegativeTest} failed.
		 * 
		 * @return The description of the negative lexical test failed, while
		 * executing it's test method.
		 */
		public String getTestDescription() {
			return testDescription;
		}
		
		/**
		 * Returns the number of source codes scanned completely successful
		 * while executing a {@link NegativeTest}.
		 * 
		 * @return Number of failed test cases while performing a
		 * {@link NegativeTest}.
		 */
		public int getNumberOfFailedTests() {
			return errors.size();
		}
		
		/**
		 * Returns the position in the list of a source code of the
		 * {@link NegativeTest}, which is in this exceptions
		 * source code list at the n'th position.
		 * 
		 * @param nthFailedTest The position of some source code
		 * in this ErrorsNegativeTest exception. Its also the
		 * position of an {@link NegativeTest.ErrorNegativeTest}
		 * in the list of {@link NegativeTest.ErrorNegativeTest}
		 * exceptions of this ErrorsNegativeTest exception.
		 * @return The position in the list of source codes in
		 * the {@link NegativeTest} object, which has thrown
		 * this ErrorsNegativeTest exception while it's test method
		 * has been executed.
		 */
		public int getTestNumber(int nthFailedTest) {
			return testNumbers.get(nthFailedTest);
		}
		
		/**
		 * Returns the n'th {@link NegativeTest.ErrorNegativeTest}
		 * exception of this ErrorsNegativeTest object.
		 * 
		 * @param nthFailedTest The position in the list of
		 * {@link NegativeTest.ErrorNegativeTest} objects of this
		 * ErrorsNegativeTest exception.
		 * @return The {@link NegativeTest.ErrorNegativeTest} in
		 * the list at the given position.
		 */
		public ErrorNegativeTest getTestError(int nthFailedTest) {
			return errors.get(nthFailedTest);
		}
	}
	
	/**
	 * Exception constructed for each failed test case while executing the test
	 * method of an {@link NegativeTest} instance. A test case failed,
	 * if it's source code has been completely successful scanned. So
	 * this exception contains the successful scanned source code, as well
	 * as the token returned by the lexer.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorNegativeTest extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private String testCode;
		private List<ILexerAdapter.TestToken> tokenRead;
		
		private ErrorNegativeTest(String errorMessage, String testCode,
				List<ILexerAdapter.TestToken> tokenRead) {
			super(errorMessage);
			
			this.testCode = testCode;
			this.tokenRead = tokenRead;
		}
		
		/**
		 * Returns the completely successful scanned source code, causing
		 * a test case of a {@link NegativeTest} to fail, while
		 * executing it's test method.
		 * 
		 * @return The successful, lexical analyzed source code.
		 */
		public String getTestCode() {
			return testCode;
		}
		
		/**
		 * Returns the token returned by the lexer for the completely successful
		 * analyzed source code associated with this ErrorNegativeTest exception.
		 * 
		 * @return List of analyzed token retrieved by successful scanning
		 * the complete source code of a test case of a {@link NegativeTest}
		 * while executing it's test method.
		 */
		public List<ILexerAdapter.TestToken> getTokenRead() {
			return tokenRead;
		}
	}
}
