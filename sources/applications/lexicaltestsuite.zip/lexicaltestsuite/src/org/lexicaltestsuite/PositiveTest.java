package org.lexicaltestsuite;

import java.io.StringReader;

import java.util.List;

import org.lexicaltestsuite.ILexerAdapter.LexingError;

/**
 * Atomic positive lexical test. A positive lexical test consist of :<br>
 *  - A test description.<br>
 *  - Arbitrary Source code.<br>
 *  - A list of {@link ILexerAdapter.TestToken token}, which the lexer has to deliver in
 *    the order of the list to show it's working correctly.<br>
 * <br>
 * The positive lexical test represented by a PositiveLexicalTest object can
 * be executed invoking it's {@link #runTest()} method. If the test failed, an
 * {@link PositiveTest.ErrorPositiveTest} exception will be thrown.
 * 
 * @author C. Bürger
 *
 */
public class PositiveTest {
	/**
	 * Description for the positive lexical test.
	 */
	public String description;
	/**
	 * The source code the scanner to test has to analyze.
	 * Each source code should be completly successful scan able.
	 */
	public String sourceCode;
	/**
	 * The token, the scanner to test has to recognize in exactly the list's
	 * order.
	 */
	public List<ILexerAdapter.TestToken> tokenToRecognize;
	
	/**
	 * Executes the lexical test, testing the lexer provided by the
	 * {@link Main#config} instance. If no exception is thrown, the
	 * test has been successful.
	 * 
	 * @throws ConfigurationException Is thrown, if the test
	 * contains errors and it was not possible to do the test at all.
	 * @throws ErrorPositiveTest Is thrown, if the test failed, thus the
	 * lexer is not working as specified by the test.
	 */
	public void runTest() throws ConfigurationException, ErrorPositiveTest {
		ILexerAdapter lexer =
			Main.config.getLexerAdapter();
		lexer.initialize(new StringReader(sourceCode));
		
		int tokenNumber = 1;
		for (ILexerAdapter.TestToken expectedToken:tokenToRecognize) {
			ILexerAdapter.TestToken returnedToken = null;
			try{
				returnedToken = lexer.nextToken();
			} catch (LexingError exception) {
				returnedToken = new ILexerAdapter.TestToken();
				returnedToken.type = null;
				returnedToken.lexem = exception.getUnknownLexem();
				
				throw new ErrorPositiveTest(
						description,
						sourceCode,
						"Unknown lexem while scanning : " + exception.getUnknownLexem() + ".",
						tokenNumber,
						expectedToken,
						returnedToken);
			}
			
			if (!returnedToken.type.equals(expectedToken.type))
				throw new ErrorPositiveTest(
						description,
						sourceCode,
						"Wrong token id : [" + returnedToken.type + "|" + expectedToken.type + "].",
						tokenNumber,
						expectedToken,
						returnedToken);
			
			if (!returnedToken.lexem.equals(expectedToken.lexem))
				throw new ErrorPositiveTest(
						description,
						sourceCode,
						"Wrong lexem : [" + returnedToken.lexem + "|" + expectedToken.lexem + "].",
						tokenNumber,
						expectedToken,
						returnedToken);
			
			tokenNumber++;
		}
	}
	
	/**
	 * Class implementing exception thrown, if a single positive test failed,
	 * while performing it's {@link PositiveTest#runTest() test method}.<br>
	 * <br>
	 * An ErrorPositiveTest exception contains :<br>
	 *  - A test description.<br>
	 *  - The source code, which has not been successful scanned.<br>
	 *  - The number of the next token, which could not be scanned. All token
	 *    before have been successful scanned.<br>
	 *  - The token, which should have been read.<br>
	 *  - The token, which has been read or the lexem, which resulted in
	 *    an error. This information is wrapped in a {@link ILexerAdapter.TestToken} as
	 *    well.<br>
	 * <br>
	 * ErrorPositiveTest exceptions are only thrown by test methods of
	 * {@link PositiveTest} objects if a test failed,
	 * and never otherwise.
	 * 
	 * @author C. Bürger
	 *
	 */
	public static class ErrorPositiveTest extends FailedTestException {
		final public static long serialVersionUID = 1L;
		
		private String testDescription;
		private String testCode;
		private int tokenNumber;
		private ILexerAdapter.TestToken testToken;
		private ILexerAdapter.TestToken tokenRead;
		
		private ErrorPositiveTest(String testDescription, String testCode,
				String errorMessage, int tokenNumber,
				ILexerAdapter.TestToken testToken, ILexerAdapter.TestToken tokenRead) {
			super(errorMessage);
			
			this.testDescription = testDescription;
			this.testCode = testCode;
			this.tokenNumber = tokenNumber;
			this.testToken = (ILexerAdapter.TestToken)testToken.clone();
			this.tokenRead = tokenRead;
		}
		
		/**
		 * Returns the description of the {@link PositiveTest} failed.
		 * 
		 * @return The description of the positive lexical test failed, while
		 * executing it's test method.
		 */
		public String getTestDescription() {
			return testDescription;
		}
		
		/**
		 * Returns the source code, the lexer has not been able to scan of a
		 * {@link PositiveTest}.
		 * 
		 * @return Source code of the test case failed, while executing a
		 * {@link PositiveTest} test method, resulting in throwing
		 * this ErrorPositiveTest exception.
		 */
		public String getTestCode() {
			return testCode;
		}
		
		/**
		 * Returns the number of the token, the lexer didn't scanned as
		 * expected while performing a {@link PositiveTest} test.
		 * 
		 * @return The number of token scanned successful + 1, while
		 * performing a {@link PositiveTest}, before the test
		 * failed.
		 */
		public int getTokenNumber() {
			return tokenNumber;
		}
		
		/**
		 * Returns the token expected next, while performing a
		 * {@link PositiveTest} test.
		 * 
		 * @return Next expected, but not delivered token, while
		 * performing a {@link PositiveTest} test.
		 */
		public ILexerAdapter.TestToken getTestToken() {
			return testToken;
		}
		
		/**
		 * Returns the token delivered, which has been wrong, while performing
		 * a {@link PositiveTest}. If the token.type == null, the lexer
		 * didn't deliver any valid token at all, instead it encountered an
		 * unknown lexem. The lexem unknown for the lexer is saved in the
		 * token returned's lexem attribute.
		 * 
		 * @return The token delivered by the lexer causing a
		 * {@link PositiveTest} to fail.
		 */
		public ILexerAdapter.TestToken getTokenRead() {
			return tokenRead;
		}
	}
}
