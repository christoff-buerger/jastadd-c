package org.lexicaltestsuite;

import java.util.Date;
import java.util.TimeZone;

import java.text.SimpleDateFormat;

import org.lexicaltestsuite.LexicalTestSuite.ErrorsLexicalTestSuite;
import org.lexicaltestsuite.LexicalTestSuite.ErrorsNegativeTestsLexicalTestSuite;
import org.lexicaltestsuite.LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite;
import org.lexicaltestsuite.LexicalTests.ErrorsLexicalTests;
import org.lexicaltestsuite.NegativeTest.ErrorNegativeTest;
import org.lexicaltestsuite.NegativeTest.ErrorsNegativeTest;
import org.lexicaltestsuite.PositiveTest.ErrorPositiveTest;

import java.util.logging.Logger;

/**
 * Class used to print log files for failed lexical tests.
 * Failed lexical tests are represented by {@link FailedTestException}s
 * and form a hierarchy, so one failed lexical test may be caused by an
 * arbitrary number of other failed lexical tests. The composition of
 * such exceptions reflects the composition of tests. Thus an
 * invocation of the {@link #handleResult(LexicalTests.ErrorsLexicalTests)} method
 * will result in implicit calls of the
 * {@link #handleResult(LexicalTestSuite.ErrorsLexicalTestSuite)} method for every
 * failed {@link LexicalTestSuite} test method executed implicitly by calling a
 * {@link LexicalTests} test method. The
 * {@link #handleResult(LexicalTestSuite.ErrorsLexicalTestSuite)} method call will
 * result implicitly in calls of the
 * {@link #handleResult(LexicalTestSuite.ErrorsNegativeTestsLexicalTestSuite)} and
 * {@link #handleResult(LexicalTestSuite.ErrorsPositiveTestsLexicalTestSuite)}
 * methods and so one.
 * 
 * @author C. Bürger
 *
 */
public class ResultPrinter implements IResultHandler {
	private static final String lineSep = System.getProperty("line.separator");
	private static final String tab = "\t";
	private Logger logger;
	
	/**
	 * Constructs a new {@link IResultHandler} printing
	 * failed tests into a log file.
	 */
	public ResultPrinter(Logger loggerToUse) {
		if (loggerToUse == null)
			throw new RuntimeException("No logger to use specified.");
		logger = loggerToUse;
	}
	
	public void handleResult(ErrorsLexicalTests error) throws ConfigurationException {
		int numberOfErrors = error.getNumberOfFailedTests();
		Date date = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		dateFormat.setTimeZone(TimeZone.getDefault());
		
		logger.info("                                             FAILED LEXICAL TESTS REPORT");
		logger.info("                                               "+ dateFormat.format(date));
		logger.info("*********************************************************************************************************************");
		logger.info("");
		logger.info("Number of lexical test suites, which didn't pass: "+ numberOfErrors);
		
		for (int i = 0; i < numberOfErrors; i++) {
			logger.info("");
			handleResult(error.getTestError(i));
		}
		
		logger.info("");
	}
	
	public void handleResult(ErrorsLexicalTestSuite error) throws ConfigurationException {
		logger.info("Failed tests in lexical test suite [" +
				error.getTestFile().getAbsolutePath() + "]: ");
		logger.info(tab + "Description: " + error.getTestFileDescription());
		
		ErrorsPositiveTestsLexicalTestSuite pErrors = error.hasErrorsPositiveTests();
		handleResult(pErrors);
		
		ErrorsNegativeTestsLexicalTestSuite nErrors = error.hasErrorsNegativeTests();
		handleResult(nErrors);
	}
	
	public void handleResult(ErrorsPositiveTestsLexicalTestSuite error) throws ConfigurationException {
		if (error != null) {
			int numberOfErrors = error.getNumberOfFailedTests();
			
			logger.info(tab);
			if (numberOfErrors > 1) {
				logger.info(tab + "Lexical test suite contains [" + numberOfErrors +
						"] failed positive tests:");
			} else {
				logger.info(tab + "Lexical test suite contains [" + numberOfErrors +
				"] failed positive test:");
			}
			
			for (int i = 0; i < numberOfErrors; i++) {
				logger.info(tab + tab);
				logger.info(tab + tab +"["+ error.getTestNumber(i) +
						"]'nth positive test of lexical test suite: ");
				
				handleResult(error.getTestError(i));
			}
		}
	}
	
	public void handleResult(ErrorsNegativeTestsLexicalTestSuite error) throws ConfigurationException {
		if (error != null) {
			int numberOfErrors = error.getNumberOfFailedTests();
			
			logger.info(tab);
			if (numberOfErrors > 1) {
				logger.info(tab + "Lexical test suite contains [" + numberOfErrors +
						"] failed negative tests:");
			} else {
				logger.info(tab + "Lexical test suite contains [" + numberOfErrors +
				"] failed negative test:");
			}
			
			for (int i = 0; i < numberOfErrors; i++) {
				logger.info(tab + tab);
				logger.info(tab + tab +"["+ error.getTestNumber(i) +
						"]'nth negative test of lexical test suite: ");
				
				handleResult(error.getTestError(i));
			}
		}
	}
	
	public void handleResult(ErrorPositiveTest error) throws ConfigurationException {
		logger.info(tab + tab + tab + "Description: " + error.getTestDescription());
		printCode(error.getTestCode(), 3);
		logger.info(tab + tab + tab + "Token number: " + error.getTokenNumber());
		ILexerAdapter.TestToken tokenRead = error.getTokenRead();
		if (tokenRead.type == null) {
			logger.info(tab + tab + tab + "Read         : unknown lexem [" +
					tokenRead.lexem + "] encountered.");
		} else {
			logger.info(tab + tab + tab + "Read         : [" + tokenRead.type +
				"|" + tokenRead.lexem + "]");
		}
		logger.info(tab + tab + tab + "Expected     : [" +
				error.getTestToken().type + "|" + error.getTestToken().lexem + "]");
	}
	
	public void handleResult(ErrorsNegativeTest error) throws ConfigurationException {
		int numberOfErrors = error.getNumberOfFailedTests();
		
		logger.info(tab + tab + tab + "Description: " + error.getTestDescription());
		if (numberOfErrors > 1) {
			logger.info(tab + tab + tab + "Failure cause: [" + numberOfErrors +
					"] source code fragments have been successfully scanned.");
		} else {
			logger.info(tab + tab + tab +"["+ numberOfErrors +
			"] source code fragment has been successful scanned.");
		}
		
		for (int i = 0; i < numberOfErrors; i++) {
			logger.info(tab + tab + tab);
			logger.info(tab + tab + tab +"["+ error.getTestNumber(i) +
					"]'nth source code fragment: ");
			
			handleResult(error.getTestError(i));
		}
	}
	
	public void handleResult(ErrorNegativeTest error) throws ConfigurationException {
		printCode(error.getTestCode(), 4);
		logger.info(tab + tab + tab + tab);
		
		for (ILexerAdapter.TestToken token:error.getTokenRead()) {
			logger.info(tab + tab + tab + tab +
					"Read: [" + token.type + "|" + token.type + "]");
		}
	}
	
	private void printCode(String code, final int numberOfTabs) {
		StringBuilder tabs = new StringBuilder(128);
		for (int i = 0; i < numberOfTabs; i++) {
			tabs.append(tab);
		}
		final String ftabs = tabs.toString();
		
		logger.info(ftabs + "|---------------CODE--------------------------------------------->>>");
		logger.info(ftabs + "|" + code.replace("\n", lineSep + ftabs + "|"));
		logger.info(ftabs + "|---------------------------------------------------------------->>>");
	}
}
